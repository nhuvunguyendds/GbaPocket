plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }; kotlinOptions { jvmTarget = "17" } namespace = "com.example.gbapocket"; compileSdk = 35
 defaultConfig { applicationId = "com.example.gbapocket"; minSdk = 26; targetSdk = 35; versionCode = 2; versionName = "1.1"; externalNativeBuild { cmake { cppFlags += "-std=c++17" } }; ndk { abiFilters += listOf("arm64-v8a") } }
 externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt") } }
}
