#include <jni.h>
#include <dlfcn.h>
#include <cstdint>
#include <vector>
#include <string>
#include <cstring>
#include <algorithm>
#include <sys/stat.h>
#include <android/log.h>
// Libretro ABI subset; see https://github.com/libretro/libretro-common/blob/master/include/libretro.h
struct retro_game_info { const char* path; const void* data; size_t size; const char* meta; };
struct retro_system_av_info;
using video_cb = void (*)(const void*, unsigned, unsigned, size_t);
using audio_cb = void (*)(int16_t,int16_t);
using audio_batch_cb = size_t (*)(const int16_t*,size_t);
using input_poll_cb = void (*)();
using input_state_cb = int16_t (*)(unsigned,unsigned,unsigned,unsigned);
using environment_cb = bool (*)(unsigned,void*);
static void* lib=nullptr;
static void (*init)()=nullptr, (*deinit)()=nullptr, (*run)()=nullptr, (*unload_game)()=nullptr;
static bool (*load_game)(const retro_game_info*)=nullptr;
static void (*set_video)(video_cb)=nullptr, (*set_audio)(audio_cb)=nullptr, (*set_audio_batch)(audio_batch_cb)=nullptr;
static void (*set_poll)(input_poll_cb)=nullptr, (*set_state)(input_state_cb)=nullptr, (*set_env)(environment_cb)=nullptr;
static std::vector<uint32_t> pixels(240*160,0xff000000);
static std::string saveDir, systemDir;
static unsigned keyMask=0;
static bool loaded=false;
static void* (*memory_data)(unsigned)=nullptr;
static size_t (*memory_size)(unsigned)=nullptr;
static size_t (*serialize_size)()=nullptr;
static bool (*serialize)(void*,size_t)=nullptr;
static bool (*unserialize)(const void*,size_t)=nullptr;

static int pixelFormat=0;
static bool environment(unsigned cmd,void* data) {
    // RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY = 9; SAVE_DIRECTORY = 31
    if(cmd==9 && data) { *static_cast<const char**>(data)=systemDir.c_str(); return true; }
    if(cmd==31 && data) { *static_cast<const char**>(data)=saveDir.c_str(); return true; }
    // RETRO_ENVIRONMENT_SET_PIXEL_FORMAT = 10: accept RGB565(2) or XRGB8888(1)
    if(cmd==10 && data) { int fmt=*static_cast<const int*>(data); if(fmt < 0 || fmt > 2) return false; pixelFormat=fmt; return true; }
    // Unsupported environment commands should return false, allowing core fallbacks.
    return false;
}
static void video(const void* data,unsigned w,unsigned h,size_t pitch) {
    if(!data || w!=240 || h!=160) return;
    for(unsigned y=0;y<h;y++) for(unsigned x=0;x<w;x++) {
        uint32_t c;
        if(pixelFormat==1) { uint32_t p=reinterpret_cast<const uint32_t*>(static_cast<const uint8_t*>(data)+y*pitch)[x]; c=0xff000000 | (p&0x00ffffff); }
        else { uint16_t p=reinterpret_cast<const uint16_t*>(static_cast<const uint8_t*>(data)+y*pitch)[x];
            if(pixelFormat==2) c=0xff000000|((p&0xf800)<<8)|((p&0x07e0)<<5)|((p&0x001f)<<3);
            else c=0xff000000|((p&0x7c00)<<9)|((p&0x03e0)<<6)|((p&0x001f)<<3);
        }
        pixels[y*240+x]=c;
    }
}
static void audio(int16_t,int16_t) {} // Audio output not yet connected
static size_t audioBatch(const int16_t*,size_t frames) { return frames; } // audio output TODO
static void poll() {}
static int16_t state(unsigned,unsigned device,unsigned,unsigned id) { return device==1 && id<16 && (keyMask&(1u<<id)) ? 1:0; }
template<typename T> static bool symbol(T& out,const char* name) { out=reinterpret_cast<T>(dlsym(lib,name)); return out!=nullptr; }
extern "C" JNIEXPORT jboolean JNICALL Java_com_example_gbapocket_NativeBridge_load(JNIEnv* env,jobject,jstring rom,jstring saves) {
    if(loaded) return JNI_FALSE;
    pixelFormat=0;
    const char* path=env->GetStringUTFChars(rom,nullptr);
    const char* dir=env->GetStringUTFChars(saves,nullptr);
    saveDir=dir; systemDir=dir;
    env->ReleaseStringUTFChars(saves,dir);
    lib=dlopen("libmgba_libretro.so",RTLD_NOW);
    if(!lib) { env->ReleaseStringUTFChars(rom,path); return JNI_FALSE; }
    bool ok=symbol(init,"retro_init")&&symbol(deinit,"retro_deinit")&&symbol(run,"retro_run")&&symbol(load_game,"retro_load_game")&&symbol(unload_game,"retro_unload_game")&&symbol(set_video,"retro_set_video_refresh")&&symbol(set_audio,"retro_set_audio_sample")&&symbol(set_audio_batch,"retro_set_audio_sample_batch")&&symbol(set_poll,"retro_set_input_poll")&&symbol(set_state,"retro_set_input_state")&&symbol(set_env,"retro_set_environment")&&symbol(memory_data,"retro_get_memory_data")&&symbol(memory_size,"retro_get_memory_size")&&symbol(serialize_size,"retro_serialize_size")&&symbol(serialize,"retro_serialize")&&symbol(unserialize,"retro_unserialize");
    if(ok) {
        set_env(environment); set_video(video); set_audio(audio); set_audio_batch(audioBatch); set_poll(poll); set_state(state); init();
        retro_game_info game{path,nullptr,0,nullptr}; ok=load_game(&game);
        if(!ok) deinit();
    }
    env->ReleaseStringUTFChars(rom,path);
    if(!ok) { dlclose(lib); lib=nullptr; return JNI_FALSE; }
    loaded=true; return JNI_TRUE;
}
extern "C" JNIEXPORT jintArray JNICALL Java_com_example_gbapocket_NativeBridge_frame(JNIEnv* env,jobject,jint keys) {
    if(!loaded) return nullptr;
    keyMask=static_cast<unsigned>(keys); run();
    jintArray out=env->NewIntArray(240*160);
    env->SetIntArrayRegion(out,0,240*160,reinterpret_cast<const jint*>(pixels.data()));
    return out;
}
extern "C" JNIEXPORT void JNICALL Java_com_example_gbapocket_NativeBridge_unload(JNIEnv*,jobject) {
    if(loaded) { unload_game(); deinit(); loaded=false; }
    if(lib) { dlclose(lib); lib=nullptr; }
}

// All native operations are invoked on the UI thread only after pausing the emulation worker.
extern "C" JNIEXPORT jbyteArray JNICALL Java_com_example_gbapocket_NativeBridge_readSave(JNIEnv* env,jobject) {
    if(!loaded || !memory_data || !memory_size) return nullptr;
    size_t n=memory_size(0); void* p=memory_data(0); // RETRO_MEMORY_SAVE_RAM
    if(!p || !n || n>4*1024*1024) return nullptr;
    jbyteArray out=env->NewByteArray((jsize)n);
    if(out) env->SetByteArrayRegion(out,0,(jsize)n,(jbyte*)p);
    return out;
}
extern "C" JNIEXPORT jboolean JNICALL Java_com_example_gbapocket_NativeBridge_writeSave(JNIEnv* env,jobject,jbyteArray bytes) {
    if(!loaded || !bytes || !memory_data || !memory_size) return JNI_FALSE;
    size_t n=memory_size(0); void* p=memory_data(0);
    if(!p || !n || n>4*1024*1024 || env->GetArrayLength(bytes)!=(jsize)n) return JNI_FALSE;
    env->GetByteArrayRegion(bytes,0,(jsize)n,(jbyte*)p);
    return JNI_TRUE;
}
extern "C" JNIEXPORT jbyteArray JNICALL Java_com_example_gbapocket_NativeBridge_saveState(JNIEnv* env,jobject) {
    if(!loaded || !serialize_size || !serialize) return nullptr;
    size_t n=serialize_size(); if(!n || n>64*1024*1024) return nullptr;
    std::vector<uint8_t> bytes(n);
    if(!serialize(bytes.data(),n)) return nullptr;
    jbyteArray out=env->NewByteArray((jsize)n);
    if(out) env->SetByteArrayRegion(out,0,(jsize)n,(jbyte*)bytes.data());
    return out;
}
extern "C" JNIEXPORT jboolean JNICALL Java_com_example_gbapocket_NativeBridge_loadState(JNIEnv* env,jobject,jbyteArray input) {
    if(!loaded || !input || !unserialize || !serialize_size) return JNI_FALSE;
    size_t n=serialize_size(); if(!n || n>64*1024*1024 || env->GetArrayLength(input)!=(jsize)n) return JNI_FALSE;
    std::vector<uint8_t> bytes(n); env->GetByteArrayRegion(input,0,(jsize)n,(jbyte*)bytes.data());
    return unserialize(bytes.data(),n) ? JNI_TRUE : JNI_FALSE;
}
