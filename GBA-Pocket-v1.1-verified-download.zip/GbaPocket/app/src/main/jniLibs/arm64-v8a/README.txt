Place the compiled ARM64 libmgba_libretro.so here. Run scripts/build-mgba-android.sh on Linux with Android NDK configured. This archive does NOT contain a compiled emulator core.
