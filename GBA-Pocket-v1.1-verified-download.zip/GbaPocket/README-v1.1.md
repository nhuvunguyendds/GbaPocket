# GBA Pocket v1.1

- Portrait and landscape layouts; Android orientation change keeps the running core loaded.
- SRAM (.sav) via libretro RETRO_MEMORY_SAVE_RAM, persisted in app-private files/Saves/<ROM SHA prefix>.sav on pause/exit.
- Save states via libretro serialization, slot 0 in app-private files/States/<ROM SHA prefix>.ss0.
- Files > Choose accessible save folder: Android document-tree picker; Files > Export .sav copies the current save into the selected directory (no overwrite).
- Files > Import .sav: size-validated import after explicit confirmation, backing up previous save.
- The game must use its in-game Save command to commit progress to SRAM; Save State captures a running snapshot.
- Note: Files are stored privately until exported; export currently writes to the selected folder root, not an automatically created subdirectory.
- Note: Sound is not implemented; customizable touch positions/transparency are future work.
- Only arm64-v8a supported. ROMs are not included.
