<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it" sourcelanguage="en_US">
<context>
    <name>LibraryTree</name>
    <message>
        <location filename="../library/LibraryModel.cpp" line="428"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../library/LibraryModel.cpp" line="430"/>
        <source>Location</source>
        <translation>Posizione</translation>
    </message>
    <message>
        <location filename="../library/LibraryModel.cpp" line="432"/>
        <source>Platform</source>
        <translation>Piattaforma</translation>
    </message>
    <message>
        <location filename="../library/LibraryModel.cpp" line="434"/>
        <source>Size</source>
        <translation>Dimensioni</translation>
    </message>
    <message>
        <location filename="../library/LibraryModel.cpp" line="436"/>
        <source>CRC32</source>
        <translation>CRC32</translation>
    </message>
</context>
<context>
    <name>QGBA</name>
    <message>
        <location filename="../utils.cpp" line="109"/>
        <source>Game Boy Advance ROMs (%1)</source>
        <translation>ROM per Game Boy Advance (%1)</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="135"/>
        <source>Game Boy ROMs (%1)</source>
        <translation>ROM per Game Boy (%1)</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="140"/>
        <source>All ROMs (%1)</source>
        <translation>Tutte le ROM (%1)</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="142"/>
        <source>%1 Video Logs (*.mvl)</source>
        <translation>%1 registro Video (*.mvl)</translation>
    </message>
</context>
<context>
    <name>QGBA::AboutScreen</name>
    <message>
        <location filename="../AboutScreen.ui" line="14"/>
        <source>About</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../AboutScreen.ui" line="23"/>
        <source>&lt;a href=&quot;http://mgba.io/&quot;&gt;Website&lt;/a&gt; • &lt;a href=&quot;https://forums.mgba.io/&quot;&gt;Forums / Support&lt;/a&gt; • &lt;a href=&quot;https://patreon.com/mgba&quot;&gt;Donate&lt;/a&gt; • &lt;a href=&quot;https://github.com/mgba-emu/mgba/tree/{gitBranch}&quot;&gt;Source&lt;/a&gt;</source>
        <translation>&lt;a href=&quot;http://mgba.io/&quot;&gt;Sito web&lt;/a&gt; • &lt;a href=&quot;https://forums.mgba.io/&quot;&gt;Forum / Supporto&lt;/a&gt; • &lt;a href=&quot;https://patreon.com/mgba&quot;&gt;Dona&lt;/a&gt; • &lt;a href=&quot;https://github.com/mgba-emu/mgba/tree/{gitBranch}&quot;&gt;Codice sorgente&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../AboutScreen.ui" line="68"/>
        <source>{projectName} would like to thank the following patrons from Patreon:</source>
        <translation>{projectName} desidera ringraziare i seguenti sponsor di Patreon:</translation>
    </message>
    <message>
        <location filename="../AboutScreen.ui" line="86"/>
        <source>© 2013 – {year} Jeffrey Pfau, licensed under the Mozilla Public License, version 2.0
Game Boy Advance is a registered trademark of Nintendo Co., Ltd.</source>
        <translation>© 2013 - {year} Jeffrey Pfau, sotto licenza Mozilla Public License, versione 2.0
Game Boy Advance è un marchio registrato di Nintendo Co., Ltd.</translation>
    </message>
    <message>
        <location filename="../AboutScreen.ui" line="177"/>
        <source>{projectName} is an open-source Game Boy Advance emulator</source>
        <translation>{projectName} è un emulatore open-source del Game Boy Advance</translation>
    </message>
    <message>
        <location filename="../AboutScreen.ui" line="41"/>
        <source>Branch: &lt;tt&gt;{gitBranch}&lt;/tt&gt;&lt;br/&gt;Revision: &lt;tt&gt;{gitCommit}&lt;/tt&gt;</source>
        <translation>Ramo Git: &lt;tt&gt;{gitBranch}&lt;/tt&gt;&lt;br/&gt;Revisione: &lt;tt&gt;{gitCommit}&lt;/tt&gt;</translation>
    </message>
</context>
<context>
    <name>QGBA::ApplicationUpdatePrompt</name>
    <message>
        <location filename="../ApplicationUpdatePrompt.ui" line="14"/>
        <source>An update is available</source>
        <translation>È disponibile un aggiornamento</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="27"/>
        <source>An update to %1 is available.
</source>
        <translation>È disponibile un aggiornamento a %1.
</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="39"/>
        <source>
Do you want to download and install it now? You will need to restart the emulator when the download is complete.</source>
        <translation>
Vuoi scaricarlo e installarlo adesso? Dovrai riavviare l&apos;emulatore quando il download sarà completato.</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="42"/>
        <source>
Auto-update is not available on this platform. If you wish to update you will need to do it manually.</source>
        <translation>
L&apos;aggiornamento automatico non è disponibile su questa piattaforma. Se vuoi aggiornare dovrai farlo manualmente.</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="46"/>
        <source>Current version: %1
New version: %2
Download size: %3</source>
        <translation>Versione attuale: %1
Nuova versione: %2
Dimensione del download: %3</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="64"/>
        <source>Downloading update...</source>
        <translation>Scaricamento aggiornamento in corso...</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="78"/>
        <source>Verifying download failed. Please update manually.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="82"/>
        <source>Downloading failed. Please update manually.</source>
        <translation>Download fallito. Si prega di aggiornare manualmente.</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="84"/>
        <source>Downloading done. Press OK to restart %1 and install the update.</source>
        <translation>Download terminato. Premi OK per riavviare %1 e installare l&apos;aggiornamento.</translation>
    </message>
</context>
<context>
    <name>QGBA::ApplicationUpdater</name>
    <message>
        <location filename="../ApplicationUpdater.cpp" line="95"/>
        <source>Stable</source>
        <translation>Stabile</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdater.cpp" line="98"/>
        <source>Development</source>
        <translation>Sviluppo</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdater.cpp" line="100"/>
        <source>Unknown</source>
        <translation>Sconosciuto</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdater.cpp" line="246"/>
        <source>(None)</source>
        <translation>(Nessuno)</translation>
    </message>
</context>
<context>
    <name>QGBA::ArchiveInspector</name>
    <message>
        <location filename="../ArchiveInspector.ui" line="14"/>
        <source>Open in archive...</source>
        <translation>Apri il file in archivio...</translation>
    </message>
    <message>
        <location filename="../ArchiveInspector.ui" line="20"/>
        <source>Loading...</source>
        <translation>Caricamento in corso...</translation>
    </message>
</context>
<context>
    <name>QGBA::AssetTile</name>
    <message>
        <location filename="../AssetTile.ui" line="41"/>
        <source>Tile #</source>
        <translation>Tile Nº</translation>
    </message>
    <message>
        <location filename="../AssetTile.ui" line="65"/>
        <source>Palette #</source>
        <translation>Tavolozza #</translation>
    </message>
    <message>
        <location filename="../AssetTile.ui" line="89"/>
        <source>Address</source>
        <translation>Indirizzo</translation>
    </message>
    <message>
        <location filename="../AssetTile.ui" line="138"/>
        <source>Red</source>
        <translation>Rosso</translation>
    </message>
    <message>
        <location filename="../AssetTile.ui" line="145"/>
        <source>Green</source>
        <translation>Verde</translation>
    </message>
    <message>
        <location filename="../AssetTile.ui" line="152"/>
        <source>Blue</source>
        <translation>Blu</translation>
    </message>
    <message>
        <location filename="../AssetTile.cpp" line="144"/>
        <location filename="../AssetTile.cpp" line="145"/>
        <location filename="../AssetTile.cpp" line="146"/>
        <source>0x%0 (%1)</source>
        <translation>0x%0 (%1)</translation>
    </message>
</context>
<context>
    <name>QGBA::AudioDevice</name>
    <message>
        <location filename="../AudioDevice.cpp" line="36"/>
        <source>Can&apos;t set format of context-less audio device</source>
        <translation>Non è stato possibile impostare il formato per il dispositivo audio</translation>
    </message>
    <message>
        <location filename="../AudioDevice.cpp" line="57"/>
        <source>Audio device is missing its core</source>
        <translation>Il dispositivo audio è mancante di un core</translation>
    </message>
    <message>
        <location filename="../AudioDevice.cpp" line="85"/>
        <source>Writing data to read-only audio device</source>
        <translation>Scrittura dati sul dispositivo in modalità sola lettura</translation>
    </message>
</context>
<context>
    <name>QGBA::AudioProcessorDummy</name>
    <message>
        <location filename="../AudioProcessorDummy.cpp" line="31"/>
        <source>Can&apos;t start an audio processor without input</source>
        <translation type="unfinished">Impossibile avviare un processore audio senza input</translation>
    </message>
</context>
<context>
    <name>QGBA::AudioProcessorQt</name>
    <message>
        <location filename="../AudioProcessorQt.cpp" line="57"/>
        <source>Can&apos;t start an audio processor without input</source>
        <translation>Impossibile avviare un processore audio senza input</translation>
    </message>
    <message>
        <location filename="../AudioProcessorQt.cpp" line="82"/>
        <source>Audio outputting to %1</source>
        <translation>Uscita audio su %1</translation>
    </message>
</context>
<context>
    <name>QGBA::AudioProcessorSDL</name>
    <message>
        <location filename="../AudioProcessorSDL.cpp" line="35"/>
        <source>Can&apos;t start an audio processor without input</source>
        <translation>Impossibile avviare un processore audio senza input</translation>
    </message>
</context>
<context>
    <name>QGBA::AutorunScriptModel</name>
    <message>
        <location filename="../scripting/AutorunScriptModel.cpp" line="32"/>
        <source>Could not load autorun script settings: unknown script info format %1</source>
        <translation>Impossibile caricare le impostazioni dello script di esecuzione automatica: formato informazioni script sconosciuto: %1</translation>
    </message>
</context>
<context>
    <name>QGBA::AutorunScriptView</name>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="14"/>
        <source>Autorun scripts</source>
        <translation>Script di esecuzione automatica</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="20"/>
        <source>Add</source>
        <translation>Aggiungi</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="30"/>
        <source>Remove</source>
        <translation>Rimuovi</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="53"/>
        <source>Move up</source>
        <translation>Sposta su</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="63"/>
        <source>Move down</source>
        <translation>Sposta giù</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="73"/>
        <source>Run scripts when starting a game</source>
        <translation>Esegui gli script al lancio del gioco</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.cpp" line="29"/>
        <source>Select a script</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGBA::BattleChipModel</name>
    <message>
        <location filename="../BattleChipModel.cpp" line="113"/>
        <source>Failed to open chip names list</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGBA::BattleChipView</name>
    <message>
        <location filename="../BattleChipView.ui" line="14"/>
        <source>BattleChip Gate</source>
        <translation>BattleChip Gate</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="67"/>
        <source>Chip name</source>
        <translation>Nome Chip</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="76"/>
        <source>Insert</source>
        <translation>Inserisci</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="87"/>
        <source>Save</source>
        <translation>Salva</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="94"/>
        <source>Load</source>
        <translation>Carica</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="114"/>
        <source>Add</source>
        <translation>Aggiungi</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="121"/>
        <source>Remove</source>
        <translation>Rimuovi</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="138"/>
        <source>Gate type</source>
        <translation>Tipo Gate</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="180"/>
        <source>Inserted</source>
        <translation>Inserito</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="194"/>
        <source>Chip ID</source>
        <translation>ID chip</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="207"/>
        <source>Update Chip data</source>
        <translation>Aggiorna dati Chip</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="219"/>
        <source>Show advanced</source>
        <translation>Mostra avanzate</translation>
    </message>
    <message>
        <location filename="../BattleChipView.cpp" line="112"/>
        <source>BattleChip data missing</source>
        <translation>Dati Battlechip mancanti</translation>
    </message>
    <message>
        <location filename="../BattleChipView.cpp" line="113"/>
        <source>BattleChip data is missing. BattleChip Gates will still work, but some graphics will be missing. Would you like to download the data now?</source>
        <translation>Dati Battlechip mancanti. I Battlechip Gates continueranno a funzionare ma alcuni elementi grafici mancheranno. Sei sicuro di voler scaricare questi dati adesso?</translation>
    </message>
    <message>
        <location filename="../BattleChipView.cpp" line="179"/>
        <location filename="../BattleChipView.cpp" line="198"/>
        <source>Select deck file</source>
        <translation>Selezione file mazzo</translation>
    </message>
    <message>
        <location filename="../BattleChipView.cpp" line="210"/>
        <source>Incompatible deck</source>
        <translation>Mazzo non compatibile</translation>
    </message>
    <message>
        <location filename="../BattleChipView.cpp" line="211"/>
        <source>The selected deck is not compatible with this Chip Gate</source>
        <translation>Il mazzo selezionato non è compatibile con questo Chip Gate</translation>
    </message>
</context>
<context>
    <name>QGBA::CheatsModel</name>
    <message>
        <location filename="../CheatsModel.cpp" line="54"/>
        <source>(untitled)</source>
        <translation>(senza titolo)</translation>
    </message>
    <message>
        <location filename="../CheatsModel.cpp" line="212"/>
        <source>Failed to open cheats file: %1</source>
        <translation>Impossibile aprire il file trucchi: %1</translation>
    </message>
</context>
<context>
    <name>QGBA::CheatsView</name>
    <message>
        <location filename="../CheatsView.ui" line="14"/>
        <source>Cheats</source>
        <translation>Trucchi</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="39"/>
        <source>Add New Code</source>
        <translation>Aggiungi nuovo codice</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="60"/>
        <source>Remove</source>
        <translation>Rimuovi</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="93"/>
        <source>Add Lines</source>
        <translation>Aggiungi linee</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="100"/>
        <source>Code type</source>
        <translation>Tipo codice</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="53"/>
        <source>Save</source>
        <translation>Salva</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="46"/>
        <source>Load</source>
        <translation>Carica</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="86"/>
        <source>Enter codes here...</source>
        <translation>Inserisci i codici qui..</translation>
    </message>
    <message>
        <location filename="../CheatsView.cpp" line="50"/>
        <location filename="../CheatsView.cpp" line="58"/>
        <source>Autodetect (recommended)</source>
        <translation>Rilevamento automatico (consigliato)</translation>
    </message>
    <message>
        <location filename="../CheatsView.cpp" line="88"/>
        <location filename="../CheatsView.cpp" line="95"/>
        <source>Select cheats file</source>
        <translation>Seleziona il file cheats</translation>
    </message>
    <message>
        <location filename="../CheatsView.cpp" line="187"/>
        <source>Some cheats could not be added. Please ensure they&apos;re formatted correctly and/or try other cheat types.</source>
        <translation>Non è stato possibile aggiungere alcuni trucchi. Assicurati che siano formattati correttamente e / o prova altri tipi di trucchi.</translation>
    </message>
</context>
<context>
    <name>QGBA::CoreController</name>
    <message>
        <location filename="../CoreController.cpp" line="106"/>
        <source>Reset r%1-%2 %3</source>
        <translation>Reset r%1-%2 %3</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="554"/>
        <location filename="../CoreController.cpp" line="571"/>
        <source>Rewinding not currently enabled</source>
        <translation>La funzione &apos;riavvolgi&apos; non è attualmente abilitata</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="610"/>
        <source>Reset the game?</source>
        <translation>Riavviare il gioco?</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="611"/>
        <source>Most games will require a reset to load the new save. Do you want to reset now?</source>
        <translation>La maggior parte dei giochi richiede un riavvio per caricare il nuovo salvataggio. Vuoi riavviare ora?</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="829"/>
        <source>Failed to open save file: %1</source>
        <translation>Impossibile aprire il file di salvataggio: %1</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="887"/>
        <source>Failed to open game file: %1</source>
        <translation>Impossibile aprire il file di gioco: %1</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="917"/>
        <source>Can&apos;t yank pack in unexpected platform!</source>
        <translation>Non riesco a strappare il pacchetto in una piattaforma inaspettata!</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="1032"/>
        <source>Failed to open snapshot file for reading: %1</source>
        <translation>Impossibile aprire il file snapshot per la lettura: %1</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="1049"/>
        <source>Failed to open snapshot file for writing: %1</source>
        <translation>Impossibile aprire il file snapshot per la scrittura: %1</translation>
    </message>
</context>
<context>
    <name>QGBA::CoreManager</name>
    <message>
        <location filename="../CoreManager.cpp" line="58"/>
        <source>Failed to open game file: %1</source>
        <translation>Impossibile aprire il file di gioco: %1</translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="105"/>
        <source>Temporary file loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="106"/>
        <source>The ROM appears to be loaded from a temporary directory, perhaps automatically extracted from an archive (e.g. a zip file).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="154"/>
        <source>Could not open save file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="155"/>
        <source>Failed to open save file; in-game saves cannot be updated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="228"/>
        <source>Would you like to copy the ROM to a different location? If you don&apos;t, this will likely lead to data loss (e.g. saves, screenshots, etc.).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="235"/>
        <source>Copy failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="235"/>
        <source>Failed to copy ROM. Do you want to try again?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="242"/>
        <source>New ROM location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="126"/>
        <source>Could not load game. Are you sure it&apos;s in the correct format?</source>
        <translation>Impossibile caricare il gioco. Sei sicuro che sia nel formato corretto?</translation>
    </message>
</context>
<context>
    <name>QGBA::DebuggerConsole</name>
    <message>
        <location filename="../DebuggerConsole.ui" line="14"/>
        <source>Debugger</source>
        <translation>Debugger</translation>
    </message>
    <message>
        <location filename="../DebuggerConsole.ui" line="27"/>
        <source>Enter command (try `help` for more info)</source>
        <translation>Inserire un comando (premere `help` per maggiori informazioni)</translation>
    </message>
    <message>
        <location filename="../DebuggerConsole.ui" line="34"/>
        <source>Break</source>
        <translation>Interruzione</translation>
    </message>
    <message>
        <location filename="../DebuggerConsole.ui" line="44"/>
        <source>Continue</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGBA::DebuggerConsoleController</name>
    <message>
        <location filename="../DebuggerConsoleController.cpp" line="190"/>
        <source>Could not open CLI history for writing</source>
        <translation>Impossibile aprire lo storico della riga di comando in scrittura</translation>
    </message>
</context>
<context>
    <name>QGBA::DisplayGL</name>
    <message>
        <location filename="../DisplayGL.cpp" line="310"/>
        <source>Failed to create an OpenGL 3 context, trying old-style...</source>
        <translation>Impossibile creare un contesto OpenGL 3, provo con il vecchio stile...</translation>
    </message>
</context>
<context>
    <name>QGBA::DolphinConnector</name>
    <message>
        <location filename="../DolphinConnector.ui" line="14"/>
        <source>Connect to Dolphin</source>
        <translation>Connetti a Dolphin</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="23"/>
        <source>Local computer</source>
        <translation>Computer locale</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="36"/>
        <source>IP address</source>
        <translation>Indirizzo IP</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="55"/>
        <source>Connect</source>
        <translation>Connetti</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="68"/>
        <source>Disconnect</source>
        <translation>Disconnetti</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="78"/>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="90"/>
        <source>Reset on connect</source>
        <translation>Reimposta alla connessione</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.cpp" line="58"/>
        <source>Couldn&apos;t Connect</source>
        <translation>Impossibile connettersi</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.cpp" line="59"/>
        <source>Could not connect to Dolphin.</source>
        <translation>Impossibile collegarsi a Dolphin.</translation>
    </message>
</context>
<context>
    <name>QGBA::ForwarderGenerator</name>
    <message>
        <location filename="../ForwarderGenerator.cpp" line="84"/>
        <source>3DS</source>
        <translation>3DS</translation>
    </message>
    <message>
        <location filename="../ForwarderGenerator.cpp" line="86"/>
        <source>Vita</source>
        <translation>Vita</translation>
    </message>
</context>
<context>
    <name>QGBA::ForwarderGenerator3DS</name>
    <message>
        <location filename="../ForwarderGenerator3DS.cpp" line="30"/>
        <source>Icon</source>
        <translation>Icona</translation>
    </message>
    <message>
        <location filename="../ForwarderGenerator3DS.cpp" line="31"/>
        <source>Banner</source>
        <translation>Striscia</translation>
    </message>
</context>
<context>
    <name>QGBA::ForwarderGeneratorVita</name>
    <message>
        <location filename="../ForwarderGeneratorVita.cpp" line="26"/>
        <source>Bubble</source>
        <translation>Bolla</translation>
    </message>
    <message>
        <location filename="../ForwarderGeneratorVita.cpp" line="27"/>
        <source>Background</source>
        <translation>Sfondo</translation>
    </message>
    <message>
        <location filename="../ForwarderGeneratorVita.cpp" line="28"/>
        <source>Startup</source>
        <translation>Avvio</translation>
    </message>
</context>
<context>
    <name>QGBA::ForwarderView</name>
    <message>
        <location filename="../ForwarderView.ui" line="14"/>
        <source>Create forwarder</source>
        <translation>Crea Icona di avvio</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="20"/>
        <source>Files</source>
        <translation>File</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="26"/>
        <source>ROM file:</source>
        <translation>File ROM:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="36"/>
        <location filename="../ForwarderView.ui" line="53"/>
        <location filename="../ForwarderView.ui" line="112"/>
        <source>Browse</source>
        <translation>Sfoglia</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="43"/>
        <source>Output filename:</source>
        <translation>Nome file in uscita:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="60"/>
        <source>Forwarder base:</source>
        <translation>Base dell&apos;Icona di avvio:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="74"/>
        <source>Latest stable version</source>
        <translation>Ultima versione stabile</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="79"/>
        <source>Latest development build</source>
        <translation>Ultima development build</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="84"/>
        <source>Specific file</source>
        <translation>File specifico</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="95"/>
        <source>Base file:</source>
        <translation>File base:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="135"/>
        <source>System</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="141"/>
        <source>3DS</source>
        <translation>3DS</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="151"/>
        <source>Vita</source>
        <translation>Vita</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="174"/>
        <source>Presentation</source>
        <translation>Presentazione</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="182"/>
        <source>Title:</source>
        <translation>Titolo:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="195"/>
        <source>Images:</source>
        <translation>Immagini:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="215"/>
        <source>Use default image</source>
        <translation>Usa immagine predefinita</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="328"/>
        <source>Preferred size:</source>
        <translation>Dimensione preferita:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="395"/>
        <source>Select image file</source>
        <translation>Seleziona file immagine</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="23"/>
        <source>Select ROM file</source>
        <translation>Seleziona file ROM</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="24"/>
        <source>Select output filename</source>
        <translation>Selezione nome file in uscita</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="25"/>
        <source>Select base file</source>
        <translation>Selezione file base</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="37"/>
        <source>Build finished</source>
        <translation>Build completata</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="38"/>
        <source>Forwarder finished building</source>
        <translation>Icona di avvio compilazione completata</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="45"/>
        <source>Build failed</source>
        <translation>Build fallita</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="46"/>
        <source>Failed to build forwarder</source>
        <translation>Impossibile compilare Icona di avvio</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="177"/>
        <source>%1 installable package (*.%2)</source>
        <translation>%1 pacchetto installabile (*.%2)</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="193"/>
        <source>Select an image</source>
        <translation>Seleziona una immagine</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="193"/>
        <source>Image files (*.png *.jpg *.bmp)</source>
        <translation>File immagine (*.png *.jpg *.bmp)</translation>
    </message>
</context>
<context>
    <name>QGBA::FrameView</name>
    <message>
        <location filename="../FrameView.ui" line="14"/>
        <source>Inspect frame</source>
        <translation>Ispeziona frame</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="41"/>
        <source>Magnification</source>
        <translation>Ingrandimento</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="50"/>
        <source>Freeze frame</source>
        <translation>Blocca frame</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="84"/>
        <source>Backdrop color</source>
        <translation>Colore sfondo</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="132"/>
        <source>Disable scanline effects</source>
        <translation>Disabilita effetto scanline</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="145"/>
        <source>Export</source>
        <translation>Esporta</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="152"/>
        <source>Reset</source>
        <translation>Reset</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="592"/>
        <source>Export frame</source>
        <translation>Esporta Frame</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="593"/>
        <source>Portable Network Graphics (*.png)</source>
        <translation>Portable Network Graphics (*.png)</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="623"/>
        <source>None</source>
        <translation>Nessuno</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="625"/>
        <source>Background</source>
        <translation>Sfondo</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="628"/>
        <source>Window</source>
        <translation>Finestra</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="631"/>
        <source>Objwin</source>
        <translation>Objwin</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="636"/>
        <source>Sprite</source>
        <translation>Sprite</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="639"/>
        <source>Backdrop</source>
        <translation>Sfondo</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="642"/>
        <source>Frame</source>
        <translation>Inquadratura</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="648"/>
        <source>%1 %2</source>
        <translation>%1x {1 %2?}</translation>
    </message>
</context>
<context>
    <name>QGBA::GBAApp</name>
    <message>
        <location filename="../GBAApp.cpp" line="84"/>
        <source>Enable Discord Rich Presence</source>
        <translation>Abilita Discord Rich Presence</translation>
    </message>
</context>
<context>
    <name>QGBA::GBAKeyEditor</name>
    <message>
        <location filename="../GBAKeyEditor.cpp" line="70"/>
        <source>Clear Button</source>
        <translation>Svuota i pulsanti</translation>
    </message>
    <message>
        <location filename="../GBAKeyEditor.cpp" line="82"/>
        <source>Clear Analog</source>
        <translation>Svuota Analogici</translation>
    </message>
    <message>
        <location filename="../GBAKeyEditor.cpp" line="93"/>
        <source>Refresh</source>
        <translation>Aggiorna</translation>
    </message>
    <message>
        <location filename="../GBAKeyEditor.cpp" line="103"/>
        <source>Set all</source>
        <translation>Imposta tutti</translation>
    </message>
</context>
<context>
    <name>QGBA::GDBWindow</name>
    <message>
        <location filename="../GDBWindow.cpp" line="32"/>
        <source>Server settings</source>
        <translation>Impostazioni Server</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="38"/>
        <source>Local port</source>
        <translation>Porta locale</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="40"/>
        <source>Bind address</source>
        <translation>Collega indirizzo</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="53"/>
        <source>Write watchpoints behavior</source>
        <translation>Comportamento watchpoint scrittura</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="64"/>
        <source>Standard GDB</source>
        <translation>Fornito da GDB</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="69"/>
        <source>Internal change detection</source>
        <translation>Riconoscimento differenze interno</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="73"/>
        <source>Break on all writes</source>
        <translation>Interrompi ad ogni scrittura</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="83"/>
        <source>Break</source>
        <translation>Interruzione</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="125"/>
        <source>Stop</source>
        <translation>Ferma</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="138"/>
        <source>Start</source>
        <translation>Avvia</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="146"/>
        <source>Crash</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="146"/>
        <source>Could not start GDB server</source>
        <translation>Impossibile avviare il server GDB</translation>
    </message>
</context>
<context>
    <name>QGBA::GIFView</name>
    <message>
        <location filename="../GIFView.ui" line="112"/>
        <source>APNG</source>
        <translation>APNG</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="51"/>
        <source>Start</source>
        <translation>Avvia</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="14"/>
        <source>Record GIF/WebP/APNG</source>
        <translation>Registra GIF/WebP/APNG</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="67"/>
        <source>Stop</source>
        <translation>Ferma</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="93"/>
        <source>Select File</source>
        <translation>Seleziona File</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="135"/>
        <source>WebP</source>
        <translation>WebP</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="145"/>
        <source>Frameskip</source>
        <translation>Salto Frame</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="122"/>
        <source>GIF</source>
        <translation>GIF</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="30"/>
        <source>Loop</source>
        <translation>Cicli</translation>
    </message>
    <message>
        <location filename="../GIFView.cpp" line="64"/>
        <source>Failed to open output file: %1</source>
        <translation>Impossibile aprire il file di output: %1</translation>
    </message>
    <message>
        <location filename="../GIFView.cpp" line="91"/>
        <source>Select output file</source>
        <translation>Seleziona file di output</translation>
    </message>
    <message>
        <location filename="../GIFView.cpp" line="91"/>
        <source>Graphics Interchange Format (*.gif);;WebP ( *.webp);;Animated Portable Network Graphics (*.png *.apng)</source>
        <translation>Formato di intercambio delle grafiche (*.gif);; WebP ( *.webp);; Grafica di rete portatile animata (*.png *.apng)</translation>
    </message>
</context>
<context>
    <name>QGBA::GameBoy</name>
    <message>
        <location filename="../GameBoy.cpp" line="62"/>
        <location filename="../GameBoy.cpp" line="81"/>
        <source>Autodetect</source>
        <translation>Rilevamento automatico</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="63"/>
        <source>Game Boy (DMG)</source>
        <translation>Game Boy (DMG)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="64"/>
        <source>Game Boy Pocket (MGB)</source>
        <translation>Game Boy Pocket (MGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="65"/>
        <source>Super Game Boy (SGB)</source>
        <translation>Super Game Boy (SGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="66"/>
        <source>Super Game Boy 2 (SGB)</source>
        <translation>Super Game Boy 2 (SGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="67"/>
        <source>Game Boy Color (CGB)</source>
        <translation>Game Boy Color (CGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="68"/>
        <source>Game Boy Advance (AGB)</source>
        <translation>Game Boy Advance (AGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="69"/>
        <source>Super Game Boy Color (SGB + CGB)</source>
        <translation>Super Game Boy Color (SGB + CGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="82"/>
        <source>ROM Only</source>
        <translation>Solo ROM</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="86"/>
        <source>%1 + RTC</source>
        <translation>%1 + RTC</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="88"/>
        <source>%1 + Rumble</source>
        <translation>%1 + Vibrazione</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="90"/>
        <source>%1 (Tilt)</source>
        <translation>%1 (Inclinazione)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="98"/>
        <source>%1 (old 1)</source>
        <translation>%1 (vecchio 1)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="99"/>
        <source>%1 (old 2)</source>
        <translation>%1 (vecchio 2)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="100"/>
        <source>%1 (new)</source>
        <translation>%1 (nuovo)</translation>
    </message>
</context>
<context>
    <name>QGBA::IOViewer</name>
    <message>
        <location filename="../IOViewer.ui" line="14"/>
        <source>I/O Viewer</source>
        <translation>Visualizzatore I/O</translation>
    </message>
    <message>
        <location filename="../IOViewer.ui" line="26"/>
        <source>0x0000</source>
        <translation>0x0000</translation>
    </message>
    <message>
        <location filename="../IOViewer.ui" line="367"/>
        <location filename="../IOViewer.cpp" line="871"/>
        <location filename="../IOViewer.cpp" line="884"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="40"/>
        <source>Background mode</source>
        <translation>Modalità sfondo</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="41"/>
        <source>Mode 0: 4 tile layers</source>
        <translation>Modalità 0: 4 strati con tavole</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="42"/>
        <source>Mode 1: 2 tile layers + 1 rotated/scaled tile layer</source>
        <translation>Modalità 1: starti con 2 tavole + 1 strato con tavola ruotata/scalata</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="43"/>
        <source>Mode 2: 2 rotated/scaled tile layers</source>
        <translation>Modalità 2: 2 strati con tavole ruotate/scalate</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="44"/>
        <source>Mode 3: Full 15-bit bitmap</source>
        <translation>Modalità 3: 15-bit bitmap completa</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="45"/>
        <source>Mode 4: Full 8-bit bitmap</source>
        <translation>Modalità 4: 8-bit bitmap completa</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="46"/>
        <source>Mode 5: Small 15-bit bitmap</source>
        <translation>Modalità 5: 15-bit bitmap piccola</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="50"/>
        <source>CGB Mode</source>
        <translation>Modalità CGB</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="51"/>
        <source>Frame select</source>
        <translation>Seleziona Frame</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="52"/>
        <source>Unlocked HBlank</source>
        <translation>HBlank sbloccato</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="53"/>
        <source>Linear OBJ tile mapping</source>
        <translation>Mappatura lineare tile OBJ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="54"/>
        <source>Force blank screen</source>
        <translation>Forza schermo bianco</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="55"/>
        <source>Enable background 0</source>
        <translation>Abilitare sfondo 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="56"/>
        <source>Enable background 1</source>
        <translation>Abilitare sfondo 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="57"/>
        <source>Enable background 2</source>
        <translation>Abilitare sfondo 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="58"/>
        <source>Enable background 3</source>
        <translation>Abilitare sfondo 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="59"/>
        <source>Enable OBJ</source>
        <translation>Abilitare OBJ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="60"/>
        <source>Enable Window 0</source>
        <translation>Abilitare Window 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="61"/>
        <source>Enable Window 1</source>
        <translation>Abilitare Window 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="62"/>
        <source>Enable OBJ Window</source>
        <translation>Abilitare Window OBJ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="66"/>
        <source>Swap green components</source>
        <translation>Scambia componenti verdi</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="70"/>
        <source>Currently in VBlank</source>
        <translation>Attualmente in VBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="71"/>
        <source>Currently in HBlank</source>
        <translation>Attualmente in HBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="72"/>
        <source>Currently in VCounter</source>
        <translation>Attualmente in VCounter</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="73"/>
        <source>Enable VBlank IRQ generation</source>
        <translation>Abilita creazione IRQ VBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="74"/>
        <source>Enable HBlank IRQ generation</source>
        <translation>Abilita creazione IRQ HBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="75"/>
        <source>Enable VCounter IRQ generation</source>
        <translation>Abilita creazione IRQ VCounter</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="76"/>
        <source>VCounter scanline</source>
        <translation>VCounter scanline</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="80"/>
        <source>Current scanline</source>
        <translation>Scanline corrente</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="84"/>
        <location filename="../IOViewer.cpp" line="93"/>
        <location filename="../IOViewer.cpp" line="102"/>
        <location filename="../IOViewer.cpp" line="112"/>
        <source>Priority</source>
        <translation>Priorità</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="85"/>
        <location filename="../IOViewer.cpp" line="94"/>
        <location filename="../IOViewer.cpp" line="103"/>
        <location filename="../IOViewer.cpp" line="113"/>
        <source>Tile data base (* 16kB)</source>
        <translation>Tile data base (* 16kB)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="86"/>
        <location filename="../IOViewer.cpp" line="95"/>
        <location filename="../IOViewer.cpp" line="104"/>
        <location filename="../IOViewer.cpp" line="114"/>
        <source>Enable mosaic</source>
        <translation>Abilita Mosaico</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="87"/>
        <location filename="../IOViewer.cpp" line="96"/>
        <location filename="../IOViewer.cpp" line="105"/>
        <location filename="../IOViewer.cpp" line="115"/>
        <source>Enable 256-color</source>
        <translation>Abilita 256 colori</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="88"/>
        <location filename="../IOViewer.cpp" line="97"/>
        <location filename="../IOViewer.cpp" line="106"/>
        <location filename="../IOViewer.cpp" line="116"/>
        <source>Tile map base (* 2kB)</source>
        <translation>Tile map base (* 2kB)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="89"/>
        <location filename="../IOViewer.cpp" line="98"/>
        <location filename="../IOViewer.cpp" line="108"/>
        <location filename="../IOViewer.cpp" line="118"/>
        <source>Background dimensions</source>
        <translation>Dimensioni dello sfondo</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="107"/>
        <location filename="../IOViewer.cpp" line="117"/>
        <source>Overflow wraps</source>
        <translation>Overflow wraps</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="122"/>
        <location filename="../IOViewer.cpp" line="130"/>
        <location filename="../IOViewer.cpp" line="138"/>
        <location filename="../IOViewer.cpp" line="146"/>
        <location filename="../IOViewer.cpp" line="1365"/>
        <location filename="../IOViewer.cpp" line="1406"/>
        <source>Horizontal offset</source>
        <translation>Compensazione orizzontale</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="126"/>
        <location filename="../IOViewer.cpp" line="134"/>
        <location filename="../IOViewer.cpp" line="142"/>
        <location filename="../IOViewer.cpp" line="150"/>
        <location filename="../IOViewer.cpp" line="1361"/>
        <location filename="../IOViewer.cpp" line="1402"/>
        <source>Vertical offset</source>
        <translation>Compensazione verticale</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="154"/>
        <location filename="../IOViewer.cpp" line="159"/>
        <location filename="../IOViewer.cpp" line="164"/>
        <location filename="../IOViewer.cpp" line="169"/>
        <location filename="../IOViewer.cpp" line="174"/>
        <location filename="../IOViewer.cpp" line="183"/>
        <location filename="../IOViewer.cpp" line="192"/>
        <location filename="../IOViewer.cpp" line="197"/>
        <location filename="../IOViewer.cpp" line="202"/>
        <location filename="../IOViewer.cpp" line="207"/>
        <location filename="../IOViewer.cpp" line="212"/>
        <location filename="../IOViewer.cpp" line="221"/>
        <source>Fractional part</source>
        <translation>Parte frazionale</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="155"/>
        <location filename="../IOViewer.cpp" line="160"/>
        <location filename="../IOViewer.cpp" line="165"/>
        <location filename="../IOViewer.cpp" line="170"/>
        <location filename="../IOViewer.cpp" line="193"/>
        <location filename="../IOViewer.cpp" line="198"/>
        <location filename="../IOViewer.cpp" line="203"/>
        <location filename="../IOViewer.cpp" line="208"/>
        <source>Integer part</source>
        <translation>Parte Intero</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="175"/>
        <location filename="../IOViewer.cpp" line="184"/>
        <location filename="../IOViewer.cpp" line="213"/>
        <location filename="../IOViewer.cpp" line="222"/>
        <source>Integer part (low)</source>
        <translation>Parte intera (lsb)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="179"/>
        <location filename="../IOViewer.cpp" line="188"/>
        <location filename="../IOViewer.cpp" line="217"/>
        <location filename="../IOViewer.cpp" line="226"/>
        <source>Integer part (high)</source>
        <translation>Parte intera (msb)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="230"/>
        <location filename="../IOViewer.cpp" line="235"/>
        <source>End x</source>
        <translation>Fine x</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="231"/>
        <location filename="../IOViewer.cpp" line="236"/>
        <source>Start x</source>
        <translation>Inizio x</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="240"/>
        <location filename="../IOViewer.cpp" line="245"/>
        <source>End y</source>
        <translation>Fine y</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="241"/>
        <location filename="../IOViewer.cpp" line="246"/>
        <source>Start y</source>
        <translation>Inizio y</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="250"/>
        <source>Window 0 enable BG 0</source>
        <translation>Window 0 BG 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="251"/>
        <source>Window 0 enable BG 1</source>
        <translation>Window 0 BG 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="252"/>
        <source>Window 0 enable BG 2</source>
        <translation>Window 0 BG 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="253"/>
        <source>Window 0 enable BG 3</source>
        <translation>Window 0 BG 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="254"/>
        <source>Window 0 enable OBJ</source>
        <translation>Window 0 OBJ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="255"/>
        <source>Window 0 enable blend</source>
        <translation>Abilita Window 0 miscelato</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="256"/>
        <source>Window 1 enable BG 0</source>
        <translation>Abilita Window 1 BG 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="257"/>
        <source>Window 1 enable BG 1</source>
        <translation>Abilita Window 1 BG 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="258"/>
        <source>Window 1 enable BG 2</source>
        <translation>Abilita Window 1 BG 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="259"/>
        <source>Window 1 enable BG 3</source>
        <translation>Abilita Window 1 BG 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="260"/>
        <source>Window 1 enable OBJ</source>
        <translation>Abilita Window 1 OBJ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="261"/>
        <source>Window 1 enable blend</source>
        <translation>Abilita Window 1 miscelato</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="265"/>
        <source>Outside window enable BG 0</source>
        <translation>Abilita Outside window BG 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="266"/>
        <source>Outside window enable BG 1</source>
        <translation>Abilita Outside window BG 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="267"/>
        <source>Outside window enable BG 2</source>
        <translation>Abilita Outside window BG 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="268"/>
        <source>Outside window enable BG 3</source>
        <translation>Abilita Outside window BG 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="269"/>
        <source>Outside window enable OBJ</source>
        <translation>Abilita Outside window OBJ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="270"/>
        <source>Outside window enable blend</source>
        <translation>Outside window mezcla</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="271"/>
        <source>OBJ window enable BG 0</source>
        <translation>Abilita OBJ window BG 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="272"/>
        <source>OBJ window enable BG 1</source>
        <translation>Abilita OBJ window BG 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="273"/>
        <source>OBJ window enable BG 2</source>
        <translation>Abilita OBJ window BG 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="274"/>
        <source>OBJ window enable BG 3</source>
        <translation>Abilita OBJ window BG 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="275"/>
        <source>OBJ window enable OBJ</source>
        <translation>Abilita OBJ window OBJ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="276"/>
        <source>OBJ window enable blend</source>
        <translation>Abilita OBJ window blend</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="281"/>
        <source>Background mosaic size vertical</source>
        <translation>Sfondo mosaico verticale</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="280"/>
        <source>Background mosaic size horizontal</source>
        <translation>Sfondo mosaico orizzontale</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="283"/>
        <source>Object mosaic size vertical</source>
        <translation>Sfondo mosaico oggetto verticale</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="282"/>
        <source>Object mosaic size horizontal</source>
        <translation>Sfondo mosaico oggetto orizzontale</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="289"/>
        <source>BG 0 target 1</source>
        <translation>BG 0 target 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="290"/>
        <source>BG 1 target 1</source>
        <translation>BG 1 target 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="291"/>
        <source>BG 2 target 1</source>
        <translation>BG 2 target 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="292"/>
        <source>BG 3 target 1</source>
        <translation>BG 3 target 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="293"/>
        <source>OBJ target 1</source>
        <translation>OBJ target 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="294"/>
        <source>Backdrop target 1</source>
        <translation>Backdrop target 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="295"/>
        <source>Blend mode</source>
        <translation>Modalità miscelazione</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="296"/>
        <source>Disabled</source>
        <translation>Disabilitato</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="297"/>
        <source>Additive blending</source>
        <translation>Miscelazione additiva</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="298"/>
        <source>Brighten</source>
        <translation>Illumina</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="299"/>
        <source>Darken</source>
        <translation>Oscura</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="301"/>
        <source>BG 0 target 2</source>
        <translation>BG 0 target 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="302"/>
        <source>BG 1 target 2</source>
        <translation>BG 1 target 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="303"/>
        <source>BG 2 target 2</source>
        <translation>BG 2 target 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="304"/>
        <source>BG 3 target 2</source>
        <translation>BG 3 target 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="305"/>
        <source>OBJ target 2</source>
        <translation>OBJ target 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="306"/>
        <source>Backdrop target 2</source>
        <translation>Backdrop target 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="310"/>
        <source>Blend A (target 1)</source>
        <translation>Miscelato A (target 1)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="311"/>
        <source>Blend B (target 2)</source>
        <translation>Miscelato B (target 2)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="315"/>
        <source>Blend Y</source>
        <translation>Miscelato Y</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="329"/>
        <location filename="../IOViewer.cpp" line="1100"/>
        <source>Sweep shifts</source>
        <translation>Sweep shifts</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="330"/>
        <location filename="../IOViewer.cpp" line="1101"/>
        <source>Sweep subtract</source>
        <translation>Sposta subastratto</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="331"/>
        <location filename="../IOViewer.cpp" line="1102"/>
        <source>Sweep time (in 1/128s)</source>
        <translation>Tempo di sweep (in 1/128s)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="335"/>
        <location filename="../IOViewer.cpp" line="351"/>
        <location filename="../IOViewer.cpp" line="375"/>
        <location filename="../IOViewer.cpp" line="397"/>
        <location filename="../IOViewer.cpp" line="1106"/>
        <location filename="../IOViewer.cpp" line="1129"/>
        <location filename="../IOViewer.cpp" line="1154"/>
        <location filename="../IOViewer.cpp" line="1179"/>
        <source>Sound length</source>
        <translation>Lunghezza del suono</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="336"/>
        <location filename="../IOViewer.cpp" line="352"/>
        <location filename="../IOViewer.cpp" line="1107"/>
        <location filename="../IOViewer.cpp" line="1130"/>
        <source>Duty cycle</source>
        <translation>Ciclo di lavoro</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="337"/>
        <location filename="../IOViewer.cpp" line="353"/>
        <location filename="../IOViewer.cpp" line="398"/>
        <location filename="../IOViewer.cpp" line="1111"/>
        <location filename="../IOViewer.cpp" line="1134"/>
        <location filename="../IOViewer.cpp" line="1183"/>
        <source>Envelope step time</source>
        <translation>Envelope step time</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="338"/>
        <location filename="../IOViewer.cpp" line="354"/>
        <location filename="../IOViewer.cpp" line="399"/>
        <location filename="../IOViewer.cpp" line="1112"/>
        <location filename="../IOViewer.cpp" line="1135"/>
        <location filename="../IOViewer.cpp" line="1184"/>
        <source>Envelope increase</source>
        <translation>Aumento envelope</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="339"/>
        <location filename="../IOViewer.cpp" line="355"/>
        <location filename="../IOViewer.cpp" line="400"/>
        <location filename="../IOViewer.cpp" line="1113"/>
        <location filename="../IOViewer.cpp" line="1136"/>
        <location filename="../IOViewer.cpp" line="1185"/>
        <source>Initial volume</source>
        <translation>Volume iniziale</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="343"/>
        <location filename="../IOViewer.cpp" line="361"/>
        <location filename="../IOViewer.cpp" line="389"/>
        <source>Sound frequency</source>
        <translation>Frequenza del suono</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="344"/>
        <location filename="../IOViewer.cpp" line="362"/>
        <location filename="../IOViewer.cpp" line="390"/>
        <location filename="../IOViewer.cpp" line="412"/>
        <location filename="../IOViewer.cpp" line="1122"/>
        <location filename="../IOViewer.cpp" line="1145"/>
        <location filename="../IOViewer.cpp" line="1172"/>
        <location filename="../IOViewer.cpp" line="1198"/>
        <source>Timed</source>
        <translation>Temporizzato</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="345"/>
        <location filename="../IOViewer.cpp" line="363"/>
        <location filename="../IOViewer.cpp" line="391"/>
        <location filename="../IOViewer.cpp" line="413"/>
        <location filename="../IOViewer.cpp" line="1123"/>
        <location filename="../IOViewer.cpp" line="1146"/>
        <location filename="../IOViewer.cpp" line="1173"/>
        <location filename="../IOViewer.cpp" line="1199"/>
        <source>Reset</source>
        <translation>Reset</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="369"/>
        <source>Double-size wave table</source>
        <translation>Tavola delle onde a doppia dimensione</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="370"/>
        <source>Active wave table</source>
        <translation>Tavola delle onde attive</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="371"/>
        <location filename="../IOViewer.cpp" line="1150"/>
        <source>Enable channel 3</source>
        <translation>Canale 3 attivo</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="376"/>
        <location filename="../IOViewer.cpp" line="1158"/>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="377"/>
        <location filename="../IOViewer.cpp" line="1159"/>
        <source>0%</source>
        <translation>0%</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="378"/>
        <location filename="../IOViewer.cpp" line="435"/>
        <location filename="../IOViewer.cpp" line="1160"/>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="379"/>
        <location filename="../IOViewer.cpp" line="434"/>
        <location filename="../IOViewer.cpp" line="1161"/>
        <source>50%</source>
        <translation>50%</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="380"/>
        <location filename="../IOViewer.cpp" line="433"/>
        <location filename="../IOViewer.cpp" line="1162"/>
        <source>25%</source>
        <translation>25%</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="381"/>
        <location filename="../IOViewer.cpp" line="382"/>
        <location filename="../IOViewer.cpp" line="383"/>
        <location filename="../IOViewer.cpp" line="384"/>
        <source>75%</source>
        <translation>75%</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="406"/>
        <location filename="../IOViewer.cpp" line="1189"/>
        <source>Clock divider</source>
        <translation>Divisore del Clock</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="407"/>
        <location filename="../IOViewer.cpp" line="1190"/>
        <source>Register stages</source>
        <translation>Stadi di registrazione</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="408"/>
        <location filename="../IOViewer.cpp" line="1191"/>
        <source>15</source>
        <translation>15</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="409"/>
        <location filename="../IOViewer.cpp" line="1192"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="411"/>
        <location filename="../IOViewer.cpp" line="1194"/>
        <source>Shifter frequency</source>
        <translation>Cambio di frequenza</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="419"/>
        <source>PSG volume right</source>
        <translation>PSG volume destro</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="420"/>
        <source>PSG volume left</source>
        <translation>PSG volume sinistro</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="421"/>
        <location filename="../IOViewer.cpp" line="1210"/>
        <source>Enable channel 1 right</source>
        <translation>Abilita Canale 1 destro</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="422"/>
        <location filename="../IOViewer.cpp" line="1211"/>
        <source>Enable channel 2 right</source>
        <translation>Abilita Canale 2 destro</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="423"/>
        <location filename="../IOViewer.cpp" line="1212"/>
        <source>Enable channel 3 right</source>
        <translation>Abilita Canale 3 destro</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="424"/>
        <location filename="../IOViewer.cpp" line="1213"/>
        <source>Enable channel 4 right</source>
        <translation>Abilita Canale 4 destro</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="425"/>
        <location filename="../IOViewer.cpp" line="1214"/>
        <source>Enable channel 1 left</source>
        <translation>Abilita Canale 1 sinistro</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="426"/>
        <location filename="../IOViewer.cpp" line="1215"/>
        <source>Enable channel 2 left</source>
        <translation>Abilita Canale 2 sinistro</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="427"/>
        <location filename="../IOViewer.cpp" line="1216"/>
        <source>Enable channel 3 left</source>
        <translation>Abilita Canale 3 sinistro</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="428"/>
        <location filename="../IOViewer.cpp" line="1217"/>
        <source>Enable channel 4 left</source>
        <translation>Abilita Canale 4 sinistro</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="432"/>
        <source>PSG master volume</source>
        <translation>PSG volume master</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="438"/>
        <source>Loud channel A</source>
        <translation>Canale A forte</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="439"/>
        <source>Loud channel B</source>
        <translation>Canale B forte</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="440"/>
        <source>Enable channel A right</source>
        <translation>Abilita Canale A destro</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="441"/>
        <source>Enable channel A left</source>
        <translation>Abilta Canale A sinistro</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="442"/>
        <source>Channel A timer</source>
        <translation>Canale A temporizzato</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="443"/>
        <location filename="../IOViewer.cpp" line="450"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="444"/>
        <location filename="../IOViewer.cpp" line="451"/>
        <location filename="../IOViewer.cpp" line="780"/>
        <location filename="../IOViewer.cpp" line="795"/>
        <location filename="../IOViewer.cpp" line="811"/>
        <location filename="../IOViewer.cpp" line="827"/>
        <location filename="../IOViewer.cpp" line="993"/>
        <location filename="../IOViewer.cpp" line="1003"/>
        <location filename="../IOViewer.cpp" line="1013"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="446"/>
        <source>Channel A reset</source>
        <translation>Resetta canale A</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="447"/>
        <source>Enable channel B right</source>
        <translation>Abilita Canale B destro</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="448"/>
        <source>Enable channel B left</source>
        <translation>Abilita Canale B sinistro</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="449"/>
        <source>Channel B timer</source>
        <translation>Canale B temporizzato</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="453"/>
        <source>Channel B reset</source>
        <translation>Resetta canale B</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="457"/>
        <location filename="../IOViewer.cpp" line="1221"/>
        <source>Active channel 1</source>
        <translation>Canale 1 attivo</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="458"/>
        <location filename="../IOViewer.cpp" line="1222"/>
        <source>Active channel 2</source>
        <translation>Canale 2 attivo</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="459"/>
        <location filename="../IOViewer.cpp" line="1223"/>
        <source>Active channel 3</source>
        <translation>Canale 3 attivo</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="460"/>
        <location filename="../IOViewer.cpp" line="1224"/>
        <source>Active channel 4</source>
        <translation>Canale 4 attivo</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="461"/>
        <location filename="../IOViewer.cpp" line="1225"/>
        <source>Enable audio</source>
        <translation>Abilitare audio</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="467"/>
        <source>Bias</source>
        <translation>Polarizzazione</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="468"/>
        <source>Resolution</source>
        <translation>Risoluzione</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="478"/>
        <location filename="../IOViewer.cpp" line="479"/>
        <location filename="../IOViewer.cpp" line="480"/>
        <location filename="../IOViewer.cpp" line="481"/>
        <location filename="../IOViewer.cpp" line="485"/>
        <location filename="../IOViewer.cpp" line="486"/>
        <location filename="../IOViewer.cpp" line="487"/>
        <location filename="../IOViewer.cpp" line="488"/>
        <location filename="../IOViewer.cpp" line="492"/>
        <location filename="../IOViewer.cpp" line="493"/>
        <location filename="../IOViewer.cpp" line="494"/>
        <location filename="../IOViewer.cpp" line="495"/>
        <location filename="../IOViewer.cpp" line="499"/>
        <location filename="../IOViewer.cpp" line="500"/>
        <location filename="../IOViewer.cpp" line="501"/>
        <location filename="../IOViewer.cpp" line="502"/>
        <location filename="../IOViewer.cpp" line="506"/>
        <location filename="../IOViewer.cpp" line="507"/>
        <location filename="../IOViewer.cpp" line="508"/>
        <location filename="../IOViewer.cpp" line="509"/>
        <location filename="../IOViewer.cpp" line="513"/>
        <location filename="../IOViewer.cpp" line="514"/>
        <location filename="../IOViewer.cpp" line="515"/>
        <location filename="../IOViewer.cpp" line="516"/>
        <location filename="../IOViewer.cpp" line="520"/>
        <location filename="../IOViewer.cpp" line="521"/>
        <location filename="../IOViewer.cpp" line="522"/>
        <location filename="../IOViewer.cpp" line="523"/>
        <location filename="../IOViewer.cpp" line="527"/>
        <location filename="../IOViewer.cpp" line="528"/>
        <location filename="../IOViewer.cpp" line="529"/>
        <location filename="../IOViewer.cpp" line="530"/>
        <location filename="../IOViewer.cpp" line="534"/>
        <location filename="../IOViewer.cpp" line="535"/>
        <location filename="../IOViewer.cpp" line="539"/>
        <location filename="../IOViewer.cpp" line="540"/>
        <location filename="../IOViewer.cpp" line="544"/>
        <location filename="../IOViewer.cpp" line="545"/>
        <location filename="../IOViewer.cpp" line="549"/>
        <location filename="../IOViewer.cpp" line="550"/>
        <location filename="../IOViewer.cpp" line="1247"/>
        <location filename="../IOViewer.cpp" line="1248"/>
        <location filename="../IOViewer.cpp" line="1252"/>
        <location filename="../IOViewer.cpp" line="1253"/>
        <location filename="../IOViewer.cpp" line="1257"/>
        <location filename="../IOViewer.cpp" line="1258"/>
        <location filename="../IOViewer.cpp" line="1262"/>
        <location filename="../IOViewer.cpp" line="1263"/>
        <location filename="../IOViewer.cpp" line="1267"/>
        <location filename="../IOViewer.cpp" line="1268"/>
        <location filename="../IOViewer.cpp" line="1272"/>
        <location filename="../IOViewer.cpp" line="1273"/>
        <location filename="../IOViewer.cpp" line="1277"/>
        <location filename="../IOViewer.cpp" line="1278"/>
        <location filename="../IOViewer.cpp" line="1282"/>
        <location filename="../IOViewer.cpp" line="1283"/>
        <location filename="../IOViewer.cpp" line="1287"/>
        <location filename="../IOViewer.cpp" line="1288"/>
        <location filename="../IOViewer.cpp" line="1292"/>
        <location filename="../IOViewer.cpp" line="1293"/>
        <location filename="../IOViewer.cpp" line="1297"/>
        <location filename="../IOViewer.cpp" line="1298"/>
        <location filename="../IOViewer.cpp" line="1302"/>
        <location filename="../IOViewer.cpp" line="1303"/>
        <location filename="../IOViewer.cpp" line="1307"/>
        <location filename="../IOViewer.cpp" line="1308"/>
        <location filename="../IOViewer.cpp" line="1312"/>
        <location filename="../IOViewer.cpp" line="1313"/>
        <location filename="../IOViewer.cpp" line="1317"/>
        <location filename="../IOViewer.cpp" line="1318"/>
        <location filename="../IOViewer.cpp" line="1322"/>
        <location filename="../IOViewer.cpp" line="1323"/>
        <source>Sample</source>
        <translation>Mostra</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="562"/>
        <location filename="../IOViewer.cpp" line="570"/>
        <location filename="../IOViewer.cpp" line="607"/>
        <location filename="../IOViewer.cpp" line="615"/>
        <location filename="../IOViewer.cpp" line="652"/>
        <location filename="../IOViewer.cpp" line="660"/>
        <location filename="../IOViewer.cpp" line="697"/>
        <location filename="../IOViewer.cpp" line="705"/>
        <source>Address (low)</source>
        <translation>Indirizzo (lsb)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="566"/>
        <location filename="../IOViewer.cpp" line="574"/>
        <location filename="../IOViewer.cpp" line="611"/>
        <location filename="../IOViewer.cpp" line="619"/>
        <location filename="../IOViewer.cpp" line="656"/>
        <location filename="../IOViewer.cpp" line="664"/>
        <location filename="../IOViewer.cpp" line="701"/>
        <location filename="../IOViewer.cpp" line="709"/>
        <source>Address (high)</source>
        <translation>Indirizzo (msb)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1117"/>
        <location filename="../IOViewer.cpp" line="1140"/>
        <location filename="../IOViewer.cpp" line="1167"/>
        <source>Sound frequency (low)</source>
        <translation>Frequenza del suono (lsb)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1121"/>
        <location filename="../IOViewer.cpp" line="1144"/>
        <location filename="../IOViewer.cpp" line="1171"/>
        <source>Sound frequency (high)</source>
        <translation>Frequenza del suono (msb)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1425"/>
        <source>Source (high)</source>
        <translation>Sorgente (msb)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1429"/>
        <source>Source (low)</source>
        <translation>Sorgente (lsb)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1433"/>
        <source>Destination (high)</source>
        <translation>Destinazione (msb)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1437"/>
        <source>Destination (low)</source>
        <translation>Destinazione (lsb)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1500"/>
        <location filename="../IOViewer.cpp" line="1512"/>
        <source>Green (low)</source>
        <translation>Verde (lsb)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1501"/>
        <location filename="../IOViewer.cpp" line="1513"/>
        <source>Green (high)</source>
        <translation>Verde (msb)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="578"/>
        <location filename="../IOViewer.cpp" line="623"/>
        <location filename="../IOViewer.cpp" line="668"/>
        <location filename="../IOViewer.cpp" line="713"/>
        <source>Word count</source>
        <translation>Contatore di parole</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="582"/>
        <location filename="../IOViewer.cpp" line="627"/>
        <location filename="../IOViewer.cpp" line="672"/>
        <location filename="../IOViewer.cpp" line="717"/>
        <source>Destination offset</source>
        <translation>Offset di destinazione</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="583"/>
        <location filename="../IOViewer.cpp" line="589"/>
        <location filename="../IOViewer.cpp" line="628"/>
        <location filename="../IOViewer.cpp" line="634"/>
        <location filename="../IOViewer.cpp" line="673"/>
        <location filename="../IOViewer.cpp" line="679"/>
        <location filename="../IOViewer.cpp" line="718"/>
        <location filename="../IOViewer.cpp" line="724"/>
        <source>Increment</source>
        <translation>Incremento</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="584"/>
        <location filename="../IOViewer.cpp" line="590"/>
        <location filename="../IOViewer.cpp" line="629"/>
        <location filename="../IOViewer.cpp" line="635"/>
        <location filename="../IOViewer.cpp" line="674"/>
        <location filename="../IOViewer.cpp" line="680"/>
        <location filename="../IOViewer.cpp" line="719"/>
        <location filename="../IOViewer.cpp" line="725"/>
        <source>Decrement</source>
        <translation>Decremento</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="585"/>
        <location filename="../IOViewer.cpp" line="591"/>
        <location filename="../IOViewer.cpp" line="630"/>
        <location filename="../IOViewer.cpp" line="636"/>
        <location filename="../IOViewer.cpp" line="675"/>
        <location filename="../IOViewer.cpp" line="681"/>
        <location filename="../IOViewer.cpp" line="720"/>
        <location filename="../IOViewer.cpp" line="726"/>
        <source>Fixed</source>
        <translation>Fissato</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="586"/>
        <location filename="../IOViewer.cpp" line="631"/>
        <location filename="../IOViewer.cpp" line="676"/>
        <location filename="../IOViewer.cpp" line="721"/>
        <source>Increment and reload</source>
        <translation>Incremento e ricarica</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="588"/>
        <location filename="../IOViewer.cpp" line="633"/>
        <location filename="../IOViewer.cpp" line="678"/>
        <location filename="../IOViewer.cpp" line="723"/>
        <source>Source offset</source>
        <translation>Offset di origine</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="594"/>
        <location filename="../IOViewer.cpp" line="639"/>
        <location filename="../IOViewer.cpp" line="684"/>
        <location filename="../IOViewer.cpp" line="730"/>
        <source>Repeat</source>
        <translation>Ripeti</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="595"/>
        <location filename="../IOViewer.cpp" line="640"/>
        <location filename="../IOViewer.cpp" line="685"/>
        <location filename="../IOViewer.cpp" line="731"/>
        <source>32-bit</source>
        <translation>32 bit</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="596"/>
        <location filename="../IOViewer.cpp" line="641"/>
        <location filename="../IOViewer.cpp" line="686"/>
        <location filename="../IOViewer.cpp" line="732"/>
        <source>Start timing</source>
        <translation>Avvia temporizzatore</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="597"/>
        <location filename="../IOViewer.cpp" line="642"/>
        <location filename="../IOViewer.cpp" line="687"/>
        <location filename="../IOViewer.cpp" line="733"/>
        <location filename="../IOViewer.cpp" line="1443"/>
        <source>Immediate</source>
        <translation>Immediato</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="598"/>
        <location filename="../IOViewer.cpp" line="643"/>
        <location filename="../IOViewer.cpp" line="688"/>
        <location filename="../IOViewer.cpp" line="734"/>
        <location filename="../IOViewer.cpp" line="945"/>
        <location filename="../IOViewer.cpp" line="962"/>
        <location filename="../IOViewer.cpp" line="1092"/>
        <location filename="../IOViewer.cpp" line="1553"/>
        <source>VBlank</source>
        <translation>VBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="599"/>
        <location filename="../IOViewer.cpp" line="644"/>
        <location filename="../IOViewer.cpp" line="689"/>
        <location filename="../IOViewer.cpp" line="735"/>
        <location filename="../IOViewer.cpp" line="946"/>
        <location filename="../IOViewer.cpp" line="963"/>
        <location filename="../IOViewer.cpp" line="1444"/>
        <source>HBlank</source>
        <translation>HBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="602"/>
        <location filename="../IOViewer.cpp" line="647"/>
        <location filename="../IOViewer.cpp" line="692"/>
        <location filename="../IOViewer.cpp" line="738"/>
        <location filename="../IOViewer.cpp" line="785"/>
        <location filename="../IOViewer.cpp" line="801"/>
        <location filename="../IOViewer.cpp" line="817"/>
        <location filename="../IOViewer.cpp" line="833"/>
        <location filename="../IOViewer.cpp" line="893"/>
        <source>IRQ</source>
        <translation>IRQ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="603"/>
        <location filename="../IOViewer.cpp" line="648"/>
        <location filename="../IOViewer.cpp" line="693"/>
        <location filename="../IOViewer.cpp" line="739"/>
        <location filename="../IOViewer.cpp" line="786"/>
        <location filename="../IOViewer.cpp" line="802"/>
        <location filename="../IOViewer.cpp" line="818"/>
        <location filename="../IOViewer.cpp" line="834"/>
        <location filename="../IOViewer.cpp" line="1074"/>
        <location filename="../IOViewer.cpp" line="1451"/>
        <location filename="../IOViewer.cpp" line="1455"/>
        <source>Enable</source>
        <translation>Abilita</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="645"/>
        <location filename="../IOViewer.cpp" line="690"/>
        <location filename="../IOViewer.cpp" line="736"/>
        <source>Audio FIFO</source>
        <translation>FIFO audio</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="727"/>
        <source>Video Capture</source>
        <translation>Cattura video</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="729"/>
        <source>DRQ</source>
        <translation>DRQ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="775"/>
        <location filename="../IOViewer.cpp" line="790"/>
        <location filename="../IOViewer.cpp" line="806"/>
        <location filename="../IOViewer.cpp" line="822"/>
        <location filename="../IOViewer.cpp" line="1044"/>
        <location filename="../IOViewer.cpp" line="1056"/>
        <location filename="../IOViewer.cpp" line="1060"/>
        <location filename="../IOViewer.cpp" line="1064"/>
        <source>Value</source>
        <translation>Valore</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="779"/>
        <location filename="../IOViewer.cpp" line="794"/>
        <location filename="../IOViewer.cpp" line="810"/>
        <location filename="../IOViewer.cpp" line="826"/>
        <source>Scale</source>
        <translation>Scala</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="781"/>
        <location filename="../IOViewer.cpp" line="796"/>
        <location filename="../IOViewer.cpp" line="812"/>
        <location filename="../IOViewer.cpp" line="828"/>
        <location filename="../IOViewer.cpp" line="1071"/>
        <source>1/64</source>
        <translation>1/64</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="782"/>
        <location filename="../IOViewer.cpp" line="797"/>
        <location filename="../IOViewer.cpp" line="813"/>
        <location filename="../IOViewer.cpp" line="829"/>
        <location filename="../IOViewer.cpp" line="1072"/>
        <source>1/256</source>
        <translation>1/256</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="783"/>
        <location filename="../IOViewer.cpp" line="798"/>
        <location filename="../IOViewer.cpp" line="814"/>
        <location filename="../IOViewer.cpp" line="830"/>
        <location filename="../IOViewer.cpp" line="1069"/>
        <source>1/1024</source>
        <translation>1/1024</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="800"/>
        <location filename="../IOViewer.cpp" line="816"/>
        <location filename="../IOViewer.cpp" line="832"/>
        <source>Cascade</source>
        <translation>Cascata</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="870"/>
        <location filename="../IOViewer.cpp" line="883"/>
        <source>A</source>
        <translation>A</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="872"/>
        <location filename="../IOViewer.cpp" line="885"/>
        <source>Select</source>
        <translation>Select</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="873"/>
        <location filename="../IOViewer.cpp" line="886"/>
        <source>Start</source>
        <translation>Start</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="874"/>
        <location filename="../IOViewer.cpp" line="887"/>
        <source>Right</source>
        <translation>Destro</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="875"/>
        <location filename="../IOViewer.cpp" line="888"/>
        <source>Left</source>
        <translation>Sinistro</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="876"/>
        <location filename="../IOViewer.cpp" line="889"/>
        <source>Up</source>
        <translation>Su</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="877"/>
        <location filename="../IOViewer.cpp" line="890"/>
        <source>Down</source>
        <translation>Giù</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="878"/>
        <location filename="../IOViewer.cpp" line="891"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="879"/>
        <location filename="../IOViewer.cpp" line="892"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="894"/>
        <source>Condition</source>
        <translation>Condizione</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="898"/>
        <source>SC</source>
        <translation>SC</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="899"/>
        <source>SD</source>
        <translation>SD</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="900"/>
        <source>SI</source>
        <translation>SI</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="901"/>
        <source>SO</source>
        <translation>SO</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="947"/>
        <location filename="../IOViewer.cpp" line="964"/>
        <source>VCounter</source>
        <translation>VCounter</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="948"/>
        <location filename="../IOViewer.cpp" line="965"/>
        <source>Timer 0</source>
        <translation>Timer 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="949"/>
        <location filename="../IOViewer.cpp" line="966"/>
        <source>Timer 1</source>
        <translation>Timer 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="950"/>
        <location filename="../IOViewer.cpp" line="967"/>
        <source>Timer 2</source>
        <translation>Timer 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="951"/>
        <location filename="../IOViewer.cpp" line="968"/>
        <source>Timer 3</source>
        <translation>Timer 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="952"/>
        <location filename="../IOViewer.cpp" line="969"/>
        <source>SIO</source>
        <translation>SIO</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="953"/>
        <location filename="../IOViewer.cpp" line="970"/>
        <source>DMA 0</source>
        <translation>DMA 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="954"/>
        <location filename="../IOViewer.cpp" line="971"/>
        <source>DMA 1</source>
        <translation>DMA 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="955"/>
        <location filename="../IOViewer.cpp" line="972"/>
        <source>DMA 2</source>
        <translation>DMA 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="956"/>
        <location filename="../IOViewer.cpp" line="973"/>
        <source>DMA 3</source>
        <translation>DMA 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="957"/>
        <location filename="../IOViewer.cpp" line="974"/>
        <source>Keypad</source>
        <translation>Tastiera</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="958"/>
        <location filename="../IOViewer.cpp" line="975"/>
        <source>Gamepak</source>
        <translation>Gamepak</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="979"/>
        <source>SRAM wait</source>
        <translation>Attesa SRAM</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="980"/>
        <location filename="../IOViewer.cpp" line="986"/>
        <location filename="../IOViewer.cpp" line="996"/>
        <location filename="../IOViewer.cpp" line="1002"/>
        <location filename="../IOViewer.cpp" line="1006"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="981"/>
        <location filename="../IOViewer.cpp" line="987"/>
        <location filename="../IOViewer.cpp" line="997"/>
        <location filename="../IOViewer.cpp" line="1007"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="982"/>
        <location filename="../IOViewer.cpp" line="988"/>
        <location filename="../IOViewer.cpp" line="992"/>
        <location filename="../IOViewer.cpp" line="998"/>
        <location filename="../IOViewer.cpp" line="1008"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="983"/>
        <location filename="../IOViewer.cpp" line="989"/>
        <location filename="../IOViewer.cpp" line="999"/>
        <location filename="../IOViewer.cpp" line="1009"/>
        <location filename="../IOViewer.cpp" line="1012"/>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="985"/>
        <source>Cart 0 non-sequential</source>
        <translation>Cart 0 non sequenziale</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="991"/>
        <source>Cart 0 sequential</source>
        <translation>Cart 0 sequenziale</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="995"/>
        <source>Cart 1 non-sequential</source>
        <translation>Cart 1 non sequenziale</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1001"/>
        <source>Cart 1 sequential</source>
        <translation>Cart 1 sequenziale</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1005"/>
        <source>Cart 2 non-sequential</source>
        <translation>Cart 2 non sequenziale</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1011"/>
        <source>Cart 2 sequential</source>
        <translation>Cart 2 sequenziale</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1015"/>
        <source>PHI terminal</source>
        <translation>Terminale PHI</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1016"/>
        <location filename="../IOViewer.cpp" line="1452"/>
        <source>Disable</source>
        <translation>Disabilita</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1017"/>
        <source>4.19MHz</source>
        <translation>4,19&#xa0;MHz</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1018"/>
        <source>8.38MHz</source>
        <translation>8,38&#xa0;MHz</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1019"/>
        <source>16.78MHz</source>
        <translation>16,78&#xa0;MHz</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1021"/>
        <source>Gamepak prefetch</source>
        <translation>Precaricamento Gamepak</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1027"/>
        <source>Enable IRQs</source>
        <translation>Abilita IRQs</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1035"/>
        <source>Right/A</source>
        <translation>Destra/A</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1036"/>
        <source>Left/B</source>
        <translation>Sinistra/B</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1037"/>
        <source>Up/Select</source>
        <translation>Sù/Select</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1038"/>
        <source>Down/Start</source>
        <translation>Giù/Start</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1039"/>
        <source>Active D-pad</source>
        <translation>D-pad attivo</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1040"/>
        <source>Active face buttons</source>
        <translation>Pulsanti laterali attivi</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1048"/>
        <source>Internal clock</source>
        <translation>Orologio interno</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1049"/>
        <source>32× clocking (CGB only)</source>
        <translation>Clicking 32x (solo CGB)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1050"/>
        <source>Transfer active</source>
        <translation>Trasferimento attivo</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1068"/>
        <source>Divider</source>
        <translation>Divisore</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1070"/>
        <source>1/16</source>
        <translation>1/16</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1093"/>
        <location filename="../IOViewer.cpp" line="1554"/>
        <source>LCD STAT</source>
        <translation>STAT LCD</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1094"/>
        <location filename="../IOViewer.cpp" line="1555"/>
        <source>Timer</source>
        <translation>Timer</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1095"/>
        <location filename="../IOViewer.cpp" line="1556"/>
        <source>Serial</source>
        <translation>Seriale</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1096"/>
        <location filename="../IOViewer.cpp" line="1557"/>
        <source>Joypad</source>
        <translation>Joypad</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1203"/>
        <source>Volume right</source>
        <translation>Volume destro</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1204"/>
        <source>Output right</source>
        <translation>Uscita a destra</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1205"/>
        <source>Volume left</source>
        <translation>Volume sinistro</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1206"/>
        <source>Output left</source>
        <translation>Uscita a sinistra</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1327"/>
        <source>Background enable/priority</source>
        <translation>Sfondo abilitato/priorità</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1328"/>
        <source>Enable sprites</source>
        <translation>Abilita sprite</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1329"/>
        <source>Double-height sprites</source>
        <translation>Sprite ad altezza doppia</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1330"/>
        <source>Background tile map</source>
        <translation>Mappa mattonelle di sfondo</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1331"/>
        <location filename="../IOViewer.cpp" line="1340"/>
        <source>0x9800 – 0x9BFF</source>
        <translation>0x9800 – 0x9BFF</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1332"/>
        <location filename="../IOViewer.cpp" line="1341"/>
        <source>0x9C00 – 0x9FFF</source>
        <translation>0x9C00 - 0x9FFF</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1334"/>
        <source>Background tile data</source>
        <translation>Dati mattonelle di sfondo</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1335"/>
        <source>0x8800 – 0x87FF</source>
        <translation>0x8800 – 0x87FF</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1336"/>
        <source>0x8000 – 0x8FFF</source>
        <translation>0x8000 – 0x8FFF</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1338"/>
        <source>Enable window</source>
        <translation>Abilita finestra</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1339"/>
        <source>Window tile map</source>
        <translation>Mappa mattonelle finestra</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1343"/>
        <source>Enable LCD</source>
        <translation>Abilita LCD</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1347"/>
        <source>Mode</source>
        <translation>Modalità</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1348"/>
        <source>0: HBlank</source>
        <translation>0: HBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1349"/>
        <source>1: VBlank</source>
        <translation>1: VBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1350"/>
        <source>2: OAM scan</source>
        <translation>2: scansione OAM</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1351"/>
        <source>3: HDraw</source>
        <translation>3: HDraw</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1353"/>
        <source>In LYC</source>
        <translation>In LYC</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1354"/>
        <source>Enable HBlank (mode 0) IRQ</source>
        <translation>Abilita IRQ HBlank (mode 0)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1355"/>
        <source>Enable VBlank (mode 1) IRQ</source>
        <translation>Abilita IRQ VBlank (mode 1)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1356"/>
        <source>Enable OAM (mode 2) IRQ</source>
        <translation>Abilita IRQ OAM (mode 2)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1357"/>
        <source>Enable LYC IRQ</source>
        <translation>Abilita IRQ LYC</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1369"/>
        <source>Current Y coordinate</source>
        <translation>Coordinate Y correnti</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1373"/>
        <source>Comparison Y coordinate</source>
        <translation>Confronto coordinate Y</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1377"/>
        <source>Start upper byte</source>
        <translation>Inizio byte superiore</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1381"/>
        <location filename="../IOViewer.cpp" line="1388"/>
        <location filename="../IOViewer.cpp" line="1395"/>
        <source>Color 0 shade</source>
        <translation>Shade Colore 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1382"/>
        <location filename="../IOViewer.cpp" line="1389"/>
        <location filename="../IOViewer.cpp" line="1396"/>
        <source>Color 1 shade</source>
        <translation>Shade Colore 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1383"/>
        <location filename="../IOViewer.cpp" line="1390"/>
        <location filename="../IOViewer.cpp" line="1397"/>
        <source>Color 2 shade</source>
        <translation>Shade Colore 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1384"/>
        <location filename="../IOViewer.cpp" line="1391"/>
        <location filename="../IOViewer.cpp" line="1398"/>
        <source>Color 3 shade</source>
        <translation>Shade Colore 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1412"/>
        <source>Prepare to switch speed</source>
        <translation>Prepara a cambiare velocità</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1413"/>
        <source>Double speed</source>
        <translation>Velocità doppia</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1419"/>
        <source>VRAM bank</source>
        <translation>VRAM bank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1441"/>
        <source>Length</source>
        <translation>Lunghezza</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1442"/>
        <source>Timing</source>
        <translation>Tempistica</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1449"/>
        <source>Write bit</source>
        <translation>Bit di scrittura</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1450"/>
        <source>Read bit</source>
        <translation>Bit di lettura</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1453"/>
        <location filename="../IOViewer.cpp" line="1454"/>
        <source>Unknown</source>
        <translation>Sconosciuto</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1494"/>
        <location filename="../IOViewer.cpp" line="1506"/>
        <source>Current index</source>
        <translation>Indice corrente</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1495"/>
        <location filename="../IOViewer.cpp" line="1507"/>
        <source>Auto-increment</source>
        <translation>Auto-incremento</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1499"/>
        <location filename="../IOViewer.cpp" line="1511"/>
        <source>Red</source>
        <translation>Rosso</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1502"/>
        <location filename="../IOViewer.cpp" line="1514"/>
        <source>Blue</source>
        <translation>Blu</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1518"/>
        <source>Sprite ordering</source>
        <translation>Ordinamento sprite</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1519"/>
        <source>OAM order</source>
        <translation>Ordine OAM</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1520"/>
        <source>x coordinate sorting</source>
        <translation>ordinamento coordinate x</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1531"/>
        <source>WRAM bank</source>
        <translation>WRAM bank</translation>
    </message>
</context>
<context>
    <name>QGBA::InputController</name>
    <message>
        <location filename="../InputController.cpp" line="732"/>
        <location filename="../InputController.cpp" line="753"/>
        <source>Could not find a valid camera format!</source>
        <translation>Impossibile trovare un formato fotocamera valido!</translation>
    </message>
    <message>
        <location filename="../InputController.cpp" line="734"/>
        <source>Camera supported format: %1</source>
        <translation>Formato supportato dalla fotocamera: %1</translation>
    </message>
</context>
<context>
    <name>QGBA::KeyEditor</name>
    <message>
        <location filename="../KeyEditor.cpp" line="46"/>
        <location filename="../KeyEditor.cpp" line="207"/>
        <source>---</source>
        <translation>---</translation>
    </message>
</context>
<context>
    <name>QGBA::LoadSaveState</name>
    <message>
        <location filename="../LoadSaveState.ui" line="14"/>
        <location filename="../LoadSaveState.ui" line="66"/>
        <source>%1 State</source>
        <translation>%1 cattura stato</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="41"/>
        <location filename="../LoadSaveState.ui" line="85"/>
        <location filename="../LoadSaveState.ui" line="107"/>
        <location filename="../LoadSaveState.ui" line="129"/>
        <location filename="../LoadSaveState.ui" line="151"/>
        <location filename="../LoadSaveState.ui" line="173"/>
        <location filename="../LoadSaveState.ui" line="195"/>
        <location filename="../LoadSaveState.ui" line="217"/>
        <location filename="../LoadSaveState.ui" line="239"/>
        <source>No Save</source>
        <translation>Senza Salvare</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="160"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="248"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="261"/>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="182"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="138"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="50"/>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="94"/>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="204"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="116"/>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="226"/>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.cpp" line="76"/>
        <source>Load State</source>
        <translation>Carica stato</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.cpp" line="76"/>
        <source>Save State</source>
        <translation>Salva stato</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.cpp" line="185"/>
        <source>Empty</source>
        <translation>Vuoto</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.cpp" line="194"/>
        <source>Corrupted</source>
        <translation>Corrotto</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.cpp" line="229"/>
        <source>Slot %1</source>
        <translation>Slot %1</translation>
    </message>
</context>
<context>
    <name>QGBA::LogConfigModel</name>
    <message>
        <location filename="../LogConfigModel.cpp" line="91"/>
        <location filename="../LogConfigModel.cpp" line="112"/>
        <source>Default</source>
        <translation>Predefinito</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="93"/>
        <source>Fatal</source>
        <translation>Fatale</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="95"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="97"/>
        <source>Warning</source>
        <translation>Avvertenze</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="99"/>
        <source>Info</source>
        <translation>Informazioni</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="101"/>
        <source>Debug</source>
        <translation>Debug</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="103"/>
        <source>Stub</source>
        <translation>Stub</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="105"/>
        <source>Game Error</source>
        <translation>Errore del gioco</translation>
    </message>
</context>
<context>
    <name>QGBA::LogController</name>
    <message>
        <location filename="../LogController.cpp" line="110"/>
        <source>[%1] %2: %3</source>
        <translation>[%1] %2: %3</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="121"/>
        <source>An error occurred</source>
        <translation>È avvenuto un errore</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="193"/>
        <source>DEBUG</source>
        <translation>DEBUG</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="195"/>
        <source>STUB</source>
        <translation>STUB</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="197"/>
        <source>INFO</source>
        <translation>INFORMAZIONI</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="199"/>
        <source>WARN</source>
        <translation>AVVERTENZA</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="201"/>
        <source>ERROR</source>
        <translation>ERRORE</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="203"/>
        <source>FATAL</source>
        <translation>FATALE</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="205"/>
        <source>GAME ERROR</source>
        <translation>ERRORE NEL GIOCO</translation>
    </message>
</context>
<context>
    <name>QGBA::LogView</name>
    <message>
        <location filename="../LogView.ui" line="14"/>
        <source>Logs</source>
        <translation>Registri</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="22"/>
        <source>Enabled Levels</source>
        <translation>Abilita livelli</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="28"/>
        <source>Debug</source>
        <translation>Debug</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="38"/>
        <source>Stub</source>
        <translation>Stub</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="48"/>
        <source>Info</source>
        <translation>Informazioni</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="58"/>
        <source>Warning</source>
        <translation>Avvertenze</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="68"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="78"/>
        <source>Fatal</source>
        <translation>Fatale</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="95"/>
        <source>Game Error</source>
        <translation>Errore del gioco</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="108"/>
        <source>Advanced settings</source>
        <translation>Impostazioni avanzate</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="128"/>
        <source>Clear</source>
        <translation>Pulisci</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="137"/>
        <source>Max Lines</source>
        <translation>Linee massime</translation>
    </message>
</context>
<context>
    <name>QGBA::MapView</name>
    <message>
        <location filename="../MapView.ui" line="14"/>
        <source>Maps</source>
        <translation>Mappe</translation>
    </message>
    <message>
        <location filename="../MapView.ui" line="43"/>
        <source>Magnification</source>
        <translation>Ingrandimento</translation>
    </message>
    <message>
        <location filename="../MapView.ui" line="124"/>
        <source>Export</source>
        <translation>Esporta</translation>
    </message>
    <message>
        <location filename="../MapView.ui" line="139"/>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="49"/>
        <source>Priority</source>
        <translation>Priorità</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="50"/>
        <location filename="../MapView.cpp" line="63"/>
        <source>Map base</source>
        <translation>Map base</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="51"/>
        <location filename="../MapView.cpp" line="64"/>
        <source>Tile base</source>
        <translation>Tile base</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="52"/>
        <source>Size</source>
        <translation>Dimensioni</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="53"/>
        <location filename="../MapView.cpp" line="65"/>
        <source>Offset</source>
        <translation>Offset</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="54"/>
        <source>Xform</source>
        <translation>Xform</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="109"/>
        <source>Map Addr.</source>
        <translation>Indir. Mappa</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="110"/>
        <source>Mirror</source>
        <translation>Speculare</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="147"/>
        <source>None</source>
        <translation>Nessuno</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="149"/>
        <source>Both</source>
        <translation>Entrambi</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="151"/>
        <source>Horizontal</source>
        <translation>Orizzontale</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="153"/>
        <source>Vertical</source>
        <translation>Verticale</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="184"/>
        <location filename="../MapView.cpp" line="185"/>
        <location filename="../MapView.cpp" line="240"/>
        <source>N/A</source>
        <translation>N/D</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="283"/>
        <source>Export map</source>
        <translation>Esporta Mappa</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="284"/>
        <source>Portable Network Graphics (*.png)</source>
        <translation>Portable Network Graphics (*.png)</translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryAccessLogController</name>
    <message>
        <location filename="../MemoryAccessLogController.cpp" line="118"/>
        <location filename="../MemoryAccessLogController.cpp" line="127"/>
        <source>Failed to open memory log file</source>
        <translation>Impossibile aprire il file di registro della memoria</translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryAccessLogModel</name>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="68"/>
        <source>Data read</source>
        <translation>Dati letti</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="70"/>
        <source>Data written</source>
        <translation>Dati scritti</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="72"/>
        <source>Code executed</source>
        <translation>Codice eseguito</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="74"/>
        <source>Code aborted</source>
        <translation>Codice abortito</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="76"/>
        <source>8-bit access</source>
        <translation>Accesso 8-bit</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="78"/>
        <source>16-bit access</source>
        <translation>Accesso 16-bit</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="80"/>
        <source>32-bit access</source>
        <translation>Accesso 32-bit</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="82"/>
        <source>64-bit access</source>
        <translation>Accesso 64-bit</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="96"/>
        <source>Accessed by instruction</source>
        <translation>Accesso da istruzione</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="98"/>
        <source>Accessed by DMA</source>
        <translation>Accesso da DMA</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="100"/>
        <source>Accessed by BIOS</source>
        <translation>Accesso da BIOS</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="102"/>
        <source>Compressed data</source>
        <translation>Dati compressi</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="104"/>
        <source>Accessed by memory copy</source>
        <translation>Accesso da copia memoria</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="106"/>
        <source>(Unknown extra bit 5)</source>
        <translation>(Sconosciuto extra bit 5)</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="108"/>
        <source>(Unknown extra bit 6)</source>
        <translation>(Sconosciuto extra bit 6)</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="110"/>
        <source>(Unknown extra bit 7)</source>
        <translation>(Sconosciuto extra bit 7)</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="112"/>
        <source>Invalid instruction</source>
        <translation>Istruzione invalida</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="114"/>
        <source>Invalid read</source>
        <translation>Lettura invalida</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="116"/>
        <source>Invalid write</source>
        <translation>Scrittura invalida</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="118"/>
        <source>Invalid executable address</source>
        <translation>Indirizzo eseguibile invalido</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="120"/>
        <source>(Private bit 0)</source>
        <translation>(Bit 0 privato)</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="122"/>
        <source>(Private bit 1)</source>
        <translation>(Bit 1 privato)</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="126"/>
        <source>ARM code</source>
        <translation>Codice ARM</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="128"/>
        <source>Instruction opcode</source>
        <translation>Istruzione opcode</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="130"/>
        <source>(Private bit 2)</source>
        <translation>(Bit 2 privato)</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="135"/>
        <source>Thumb code</source>
        <translation>Codice thumb</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="137"/>
        <source>Instruction operand</source>
        <translation>Istruzione operando</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="139"/>
        <source>(Private bit 3)</source>
        <translation>(Bit 3 privato)</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="147"/>
        <source>(Unknown)</source>
        <translation>(Sconosciuto)</translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryAccessLogView</name>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="14"/>
        <source>Memory access logging</source>
        <translation>Registrazione accessi alla memoria</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="23"/>
        <source>Log file</source>
        <translation>File di registro</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="32"/>
        <source>Browse</source>
        <translation>Sfoglia</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="39"/>
        <source>Log additional information (uses 3× space)</source>
        <translation>Registra informazioni aggiuntive (utilizza 3× spazio)</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="46"/>
        <source>Load existing file if present</source>
        <translation>Carica file esistente se presente</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="56"/>
        <source>Load</source>
        <translation>Carica</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="66"/>
        <source>Unload</source>
        <translation>Libera</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="76"/>
        <source>Regions</source>
        <translation>Regioni</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="87"/>
        <source>Export ROM snapshot</source>
        <translation>Esporta istantanea ROM</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="94"/>
        <source>Start</source>
        <translation>Avvia</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="104"/>
        <source>Stop</source>
        <translation>Ferma</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.cpp" line="97"/>
        <location filename="../MemoryAccessLogView.cpp" line="112"/>
        <source>Select access log file</source>
        <translation>Seleziona il file di registro di accesso</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.cpp" line="97"/>
        <source>Memory access logs (*.mal)</source>
        <translation>Registri degli accessi alla memoria (*.mal)</translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryDump</name>
    <message>
        <location filename="../MemoryDump.ui" line="14"/>
        <source>Save Memory Range</source>
        <translation>Salva selezione memoria</translation>
    </message>
    <message>
        <location filename="../MemoryDump.ui" line="20"/>
        <source>Start Address:</source>
        <translation>Da Indirizzo:</translation>
    </message>
    <message>
        <location filename="../MemoryDump.ui" line="76"/>
        <source>Byte Count:</source>
        <translation>Numero di Byte:</translation>
    </message>
    <message>
        <location filename="../MemoryDump.ui" line="108"/>
        <source>Dump across banks within region</source>
        <comment>Generate dump with bytes all within the same region of memory, even if it crosses the bank boundary</comment>
        <translation type="unfinished">Fai il dump tra i banchi di memoria</translation>
    </message>
    <message>
        <location filename="../MemoryDump.cpp" line="25"/>
        <source>Save memory region</source>
        <translation>Salva regione memoria</translation>
    </message>
    <message>
        <location filename="../MemoryDump.cpp" line="31"/>
        <source>Failed to open output file: %1</source>
        <translation>Impossibile aprire il file di output: %1</translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryModel</name>
    <message>
        <location filename="../MemoryModel.cpp" line="46"/>
        <source>Copy selection</source>
        <translation>Copia selezione</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="51"/>
        <source>Save selection</source>
        <translation>Salva selezione</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="56"/>
        <source>Paste</source>
        <translation>Incolla</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="61"/>
        <source>Load</source>
        <translation>Carica</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="119"/>
        <source>All</source>
        <translation>Tutto</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="169"/>
        <source>Load TBL</source>
        <translation>Carica TBL</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="223"/>
        <source>Save selected memory</source>
        <translation>Salva la memoria selezionata</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="229"/>
        <source>Failed to open output file: %1</source>
        <translation>Impossibile aprire il file di output: %1</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="237"/>
        <source>Load memory</source>
        <translation>Carica memoria</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="243"/>
        <source>Failed to open input file: %1</source>
        <translation>Impossibile aprire il file di input: %1</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="358"/>
        <source>ISO-8859-1</source>
        <translation>ISO-8859-1</translation>
    </message>
</context>
<context>
    <name>QGBA::MemorySearch</name>
    <message>
        <location filename="../MemorySearch.ui" line="26"/>
        <source>Memory Search</source>
        <translation>Ricerca Memoria</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="51"/>
        <source>Address</source>
        <translation>Indirizzo</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="56"/>
        <source>Current Value</source>
        <translation>Valore corrente</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="61"/>
        <location filename="../MemorySearch.ui" line="81"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="71"/>
        <source>Value</source>
        <translation>Valore</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="88"/>
        <source>Numeric</source>
        <translation>Numerico</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="101"/>
        <source>Text</source>
        <translation>Testo</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="118"/>
        <source>Width</source>
        <translation>Larghezza</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="125"/>
        <location filename="../MemorySearch.ui" line="185"/>
        <source>Guess</source>
        <translation>Indovina</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="138"/>
        <source>1 Byte (8-bit)</source>
        <translation>1 Byte (8-bit)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="148"/>
        <source>2 Bytes (16-bit)</source>
        <translation>2 Bytes (16-bit)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="158"/>
        <source>4 Bytes (32-bit)</source>
        <translation>4 Bytes (32-bit)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="178"/>
        <source>Number type</source>
        <translation>Tipo di numero</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="195"/>
        <source>Decimal</source>
        <translation>Decimale</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="202"/>
        <source>Hexadecimal</source>
        <translation>Esadecimale</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="216"/>
        <source>Search type</source>
        <translation>Tipo di ricerca</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="223"/>
        <source>Equal to value</source>
        <translation>Uguale al valore</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="236"/>
        <source>Greater than value</source>
        <translation>Più del valore</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="246"/>
        <source>Less than value</source>
        <translation>Meno del valore</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="256"/>
        <source>Unknown/changed</source>
        <translation>Sconos./cambiato</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="269"/>
        <source>Changed by value</source>
        <translation>Cambiato dal valore</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="282"/>
        <source>Unchanged</source>
        <translation>Non cambiato</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="295"/>
        <source>Increased</source>
        <translation>Incrementato</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="308"/>
        <source>Decreased</source>
        <translation>Decrementato</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="318"/>
        <source>Search ROM</source>
        <translation>Cerca nella ROM</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="336"/>
        <source>New Search</source>
        <translation>Nuova Ricerca</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="343"/>
        <source>Search Within</source>
        <translation>Cerca all&apos;interno</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="350"/>
        <source>Open in Memory Viewer</source>
        <translation>Apri nel Visualizzatore Memoria</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="357"/>
        <source>Refresh</source>
        <translation>Aggiorna</translation>
    </message>
    <message>
        <location filename="../MemorySearch.cpp" line="224"/>
        <source> (%0/%1×)</source>
        <translation> (%0/%1×)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.cpp" line="226"/>
        <source> (⅟%0×)</source>
        <translation> (⅟%0×)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.cpp" line="229"/>
        <source> (%0×)</source>
        <translation> (%0×)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.cpp" line="233"/>
        <source>%1 byte%2</source>
        <translation>%1 byte%2</translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryView</name>
    <message>
        <location filename="../MemoryView.ui" line="14"/>
        <source>Memory</source>
        <translation>Memoria</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="192"/>
        <source>String:</source>
        <translation>Stringa:</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="205"/>
        <source>Load TBL</source>
        <translation>Carica TBL</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="233"/>
        <source>Copy Selection</source>
        <translation>Copia la selezione</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="247"/>
        <source>Paste</source>
        <translation>Incolla</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="240"/>
        <source>Save Selection</source>
        <translation>Salva la selezione</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="37"/>
        <source>Address:</source>
        <translation>Indirizzo:</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="106"/>
        <source>Alignment:</source>
        <translation>Allineamento:</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="120"/>
        <source>1 Byte</source>
        <translation>1 Byte</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="125"/>
        <source>2 Bytes</source>
        <translation>2 Byte</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="130"/>
        <source>4 Bytes</source>
        <translation>4 Byte</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="152"/>
        <source>Signed:</source>
        <translation>Signed:</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="172"/>
        <source>Unsigned:</source>
        <translation>Unsigned:</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="254"/>
        <source>Save Range</source>
        <translation>Salva Intervallo</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="267"/>
        <source>Load</source>
        <translation>Carica</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="282"/>
        <source>Selected address accesses</source>
        <translation>Accessi indirizzo selezionato</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="304"/>
        <source>Logging configuration</source>
        <translation>Configurazione registro</translation>
    </message>
</context>
<context>
    <name>QGBA::MessagePainter</name>
    <message>
        <location filename="../MessagePainter.cpp" line="82"/>
        <source>Frame %1</source>
        <translation>Frame %1</translation>
    </message>
</context>
<context>
    <name>QGBA::MultiplayerController</name>
    <message>
        <location filename="../MultiplayerController.cpp" line="314"/>
        <source>Couldn&apos;t find available save ID</source>
        <translation>Impossibile trovare un ID disponibile per il salvataggio</translation>
    </message>
    <message>
        <location filename="../MultiplayerController.cpp" line="368"/>
        <source>Trying to detach a multiplayer player that&apos;s not attached</source>
        <translation>Tentativo di scollegare un giocatore in multi che non è collegato</translation>
    </message>
    <message>
        <location filename="../MultiplayerController.cpp" line="408"/>
        <source>Clearing invalid save ID</source>
        <translation>Pulizia ID salvataggio invalido</translation>
    </message>
    <message>
        <location filename="../MultiplayerController.cpp" line="417"/>
        <source>Clearing invalid preferred ID</source>
        <translation>Pulizia ID preferito invalido</translation>
    </message>
    <message>
        <location filename="../MultiplayerController.cpp" line="438"/>
        <source>Trying to get player ID for a multiplayer player that&apos;s not attached</source>
        <translation>Cerco di ottenere l&apos;ID giocatore per un giocatore in multi non collegato</translation>
    </message>
    <message>
        <location filename="../MultiplayerController.cpp" line="452"/>
        <source>Trying to get save ID for a multiplayer player that&apos;s not attached</source>
        <translation>Cerco di ottenere l&apos;ID di salvataggio per un giocatore in multi non collegato</translation>
    </message>
</context>
<context>
    <name>QGBA::ObjView</name>
    <message>
        <location filename="../ObjView.ui" line="14"/>
        <source>Sprites</source>
        <translation>Sprites</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="122"/>
        <source>Magnification</source>
        <translation>Ingrandimento</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="389"/>
        <source>Export</source>
        <translation>Esporta</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="402"/>
        <source>Attributes</source>
        <translation>Attributi</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="410"/>
        <source>Transform</source>
        <translation>Trasformazione</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="430"/>
        <location filename="../ObjView.cpp" line="182"/>
        <source>Off</source>
        <translation>No</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="444"/>
        <source>Palette</source>
        <translation>Tavolozza</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="94"/>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="316"/>
        <source>Matrix</source>
        <translation>Matrix</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="481"/>
        <source>Double Size</source>
        <translation>Dimensioni doppie</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="548"/>
        <location filename="../ObjView.ui" line="561"/>
        <location filename="../ObjView.ui" line="632"/>
        <source>Return, Ctrl+R</source>
        <translation>Return, Ctrl+R</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="522"/>
        <source>Flipped</source>
        <translation>Flippato</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="545"/>
        <source>H</source>
        <extracomment>Short for horizontal</extracomment>
        <translation>H</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="558"/>
        <source>V</source>
        <extracomment>Short for vertical</extracomment>
        <translation>V</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="572"/>
        <source>Mode</source>
        <translation>Modalità</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="592"/>
        <location filename="../ObjView.cpp" line="191"/>
        <source>Normal</source>
        <translation>Normale</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="606"/>
        <source>Mosaic</source>
        <translation>Mosaico</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="643"/>
        <source>Enabled</source>
        <translation>Abilitato</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="677"/>
        <source>Priority</source>
        <translation>Priorità</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="715"/>
        <source>Tile</source>
        <translation>Tile</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="137"/>
        <source>Geometry</source>
        <translation>Geometria</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="145"/>
        <source>Position</source>
        <translation>Posizione</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="224"/>
        <source>Dimensions</source>
        <translation>Dimensioni</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="72"/>
        <source>Address</source>
        <translation>Indirizzo</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="161"/>
        <location filename="../ObjView.cpp" line="250"/>
        <source>0x%0</source>
        <translation>0x%0</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="183"/>
        <location filename="../ObjView.cpp" line="184"/>
        <location filename="../ObjView.cpp" line="185"/>
        <location filename="../ObjView.cpp" line="186"/>
        <location filename="../ObjView.cpp" line="258"/>
        <location filename="../ObjView.cpp" line="259"/>
        <location filename="../ObjView.cpp" line="260"/>
        <location filename="../ObjView.cpp" line="261"/>
        <source>---</source>
        <translation>---</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="194"/>
        <source>Trans</source>
        <translation>Trans</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="197"/>
        <source>OBJWIN</source>
        <translation>OBJWIN</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="200"/>
        <source>Invalid</source>
        <translation>Non valido</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="257"/>
        <location filename="../ObjView.cpp" line="262"/>
        <source>N/A</source>
        <translation>N/D</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="288"/>
        <source>Export sprite</source>
        <translation>Esporta sprite</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="289"/>
        <source>Portable Network Graphics (*.png)</source>
        <translation>Portable Network Graphics (*.png)</translation>
    </message>
</context>
<context>
    <name>QGBA::OverrideView</name>
    <message>
        <location filename="../OverrideView.ui" line="20"/>
        <source>Game Overrides</source>
        <translation>Valori specifici per il gioco</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="30"/>
        <source>Game Boy Advance</source>
        <translation>Game Boy Advance</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="42"/>
        <location filename="../OverrideView.ui" line="121"/>
        <location filename="../OverrideView.ui" line="241"/>
        <location filename="../OverrideView.ui" line="257"/>
        <source>Autodetect</source>
        <translation>Rilevamento automatico</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="55"/>
        <source>Realtime clock</source>
        <translation>Orologio in tempo reale</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="65"/>
        <source>Gyroscope</source>
        <translation>Giroscopio</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="75"/>
        <source>Tilt</source>
        <translation>Inclinazione</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="85"/>
        <source>Light sensor</source>
        <translation>Sensore di luce</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="95"/>
        <source>Rumble</source>
        <translation>Vibrazione</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="113"/>
        <source>Save type</source>
        <translation>Tipo di salvataggio</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="126"/>
        <source>None</source>
        <translation>Nessuno</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="131"/>
        <source>SRAM</source>
        <translation>SRAM</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="136"/>
        <source>Flash 512kb</source>
        <translation>Flash 512kb</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="141"/>
        <source>Flash 1Mb</source>
        <translation>Flash 1Mb</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="146"/>
        <source>EEPROM 8kB</source>
        <translation>EEPROM 8kB</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="151"/>
        <source>EEPROM 512 bytes</source>
        <translation>EEPROM 512 byte</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="156"/>
        <source>SRAM 64kB (bootlegs only)</source>
        <translation>SRAM 64kB (solo bootleg)</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="164"/>
        <source>Idle loop</source>
        <translation>Ciclo vuoto</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="190"/>
        <source>Game Boy Player features</source>
        <translation>Caratteristiche Game Boy Player</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="197"/>
        <source>VBA bug compatibility mode</source>
        <translation>Modalità compatibilità bug VBA</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="227"/>
        <source>Game Boy</source>
        <translation>Game Boy</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="233"/>
        <source>Game Boy model</source>
        <translation>Modello di Game Boy</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="249"/>
        <source>Memory bank controller</source>
        <translation>Controller del banco di memoria</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="265"/>
        <source>Background Colors</source>
        <translation>Colori di sfondo</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="352"/>
        <source>Sprite Colors 1</source>
        <translation>Colori Sprite 1</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="359"/>
        <source>Sprite Colors 2</source>
        <translation>Colori Sprite 2</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="529"/>
        <source>Palette preset</source>
        <translation>Profilo tavolozza</translation>
    </message>
    <message>
        <location filename="../OverrideView.cpp" line="68"/>
        <source>Official MBCs</source>
        <translation>MBC ufficiali</translation>
    </message>
    <message>
        <location filename="../OverrideView.cpp" line="72"/>
        <source>Licensed MBCs</source>
        <translation>MBC con licenza</translation>
    </message>
    <message>
        <location filename="../OverrideView.cpp" line="76"/>
        <source>Unlicensed MBCs</source>
        <translation>MBC senza licenza</translation>
    </message>
</context>
<context>
    <name>QGBA::PaletteView</name>
    <message>
        <location filename="../PaletteView.ui" line="14"/>
        <source>Palette</source>
        <translation>Tavolozza</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="44"/>
        <source>Background</source>
        <translation>Sfondo</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="94"/>
        <source>Objects</source>
        <translation>Oggetti</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="153"/>
        <source>Selection</source>
        <translation>Selezione</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="184"/>
        <source>Red</source>
        <translation>Rosso</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="191"/>
        <source>Green</source>
        <translation>Verde</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="198"/>
        <source>Blue</source>
        <translation>Blu</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="253"/>
        <source>16-bit value</source>
        <translation>Valore in 16 bits</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="260"/>
        <source>Hex code</source>
        <translation>Codice esadecimale</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="267"/>
        <source>Palette index</source>
        <translation>Indice palette</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="340"/>
        <source>Export BG</source>
        <translation>Esporta sfondo (BG)</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="360"/>
        <source>Export OBJ</source>
        <translation>Esporta OBJ</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="119"/>
        <source>#%0</source>
        <translation>#%0</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="120"/>
        <source>0x%0</source>
        <translation>0x%0</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="121"/>
        <location filename="../PaletteView.cpp" line="122"/>
        <location filename="../PaletteView.cpp" line="123"/>
        <location filename="../PaletteView.cpp" line="124"/>
        <source>0x%0 (%1)</source>
        <translation>0x%0 (%1)</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="136"/>
        <source>Export palette</source>
        <translation>Esporta palette</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="137"/>
        <source>Windows PAL (*.pal);;Adobe Color Table (*.act)</source>
        <translation>WIndows PAL (*.pal);;Tabella dei colori Adobe (*.act)</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="143"/>
        <source>Failed to open output palette file: %1</source>
        <translation>Errore nell&apos;aprire il file palette di output: %1</translation>
    </message>
</context>
<context>
    <name>QGBA::PlacementControl</name>
    <message>
        <location filename="../PlacementControl.ui" line="20"/>
        <source>Adjust placement</source>
        <translation>Regola posizionamento</translation>
    </message>
    <message>
        <location filename="../PlacementControl.ui" line="26"/>
        <source>All</source>
        <translation>Tutto</translation>
    </message>
    <message>
        <location filename="../PlacementControl.ui" line="65"/>
        <source>Offset</source>
        <translation>Offset</translation>
    </message>
    <message>
        <location filename="../PlacementControl.ui" line="72"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../PlacementControl.ui" line="79"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
</context>
<context>
    <name>QGBA::PrinterView</name>
    <message>
        <location filename="../PrinterView.ui" line="14"/>
        <source>Game Boy Printer</source>
        <translation>Stampante Game Boy</translation>
    </message>
    <message>
        <location filename="../PrinterView.ui" line="130"/>
        <source>Hurry up!</source>
        <translation>Sbrigati!</translation>
    </message>
    <message>
        <location filename="../PrinterView.ui" line="137"/>
        <source>Tear off</source>
        <translation>Strappa</translation>
    </message>
    <message>
        <location filename="../PrinterView.ui" line="223"/>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <location filename="../PrinterView.ui" line="180"/>
        <source>Magnification</source>
        <translation>Ingrandimento</translation>
    </message>
    <message>
        <location filename="../PrinterView.cpp" line="60"/>
        <source>Save Printout</source>
        <translation>Salva stampato</translation>
    </message>
    <message>
        <location filename="../PrinterView.cpp" line="60"/>
        <source>Portable Network Graphics (*.png)</source>
        <translation>Portable Network Graphics (*.png)</translation>
    </message>
</context>
<context>
    <name>QGBA::ROMInfo</name>
    <message>
        <location filename="../ROMInfo.cpp" line="48"/>
        <location filename="../ROMInfo.cpp" line="62"/>
        <location filename="../ROMInfo.cpp" line="70"/>
        <location filename="../ROMInfo.cpp" line="78"/>
        <location filename="../ROMInfo.cpp" line="89"/>
        <location filename="../ROMInfo.cpp" line="102"/>
        <source>(unknown)</source>
        <translation>(sconosciuto)</translation>
    </message>
    <message>
        <location filename="../ROMInfo.cpp" line="57"/>
        <source> bytes</source>
        <translation> bytes</translation>
    </message>
    <message>
        <location filename="../ROMInfo.cpp" line="92"/>
        <source>(no database present)</source>
        <translation>(nessun database presente)</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="14"/>
        <source>ROM Info</source>
        <translation>Informazioni sulla ROM</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="23"/>
        <source>File information</source>
        <translation>Informazioni file</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="29"/>
        <source>Game name:</source>
        <translation>Nome del gioco:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="83"/>
        <source>MD5</source>
        <translation>MD5</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="100"/>
        <source>SHA-1</source>
        <translation>SHA-1</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="134"/>
        <source>ROM header</source>
        <translation>ROM header</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="140"/>
        <source>Internal name:</source>
        <translation>Nome interno:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="157"/>
        <source>Game ID:</source>
        <translation>ID del gioco:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="174"/>
        <source>Maker Code:</source>
        <translation>Codice fabbricante:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="191"/>
        <source>Revision:</source>
        <translation>Revisione:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="49"/>
        <source>File size:</source>
        <translation>Dimensioni del file:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="66"/>
        <source>CRC32:</source>
        <translation>CRC32:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="117"/>
        <source>Save file:</source>
        <translation>Salva file:</translation>
    </message>
</context>
<context>
    <name>QGBA::ReportView</name>
    <message>
        <location filename="../ReportView.cpp" line="436"/>
        <source>Bug report archive</source>
        <translation>Archivio delle segnalazioni di bug</translation>
    </message>
    <message>
        <location filename="../ReportView.cpp" line="436"/>
        <source>ZIP archive (*.zip)</source>
        <translation>Archivio ZIP (*.zip)</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="14"/>
        <source>Generate Bug Report</source>
        <translation>Genera segnalazione bug</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="67"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;To file a bug report, please first generate a report file to attach to the bug report you&apos;re about to file. It is recommended that you include the save files, as these often help with debugging issues. This will collect some information about the version of {projectName} you&apos;re running, your configuration, your computer, and the game you currently have open (if any). Once this collection is completed you can review all of the information gathered below and save it to a zip file. The collection will automatically attempt to redact any personal information, such as your username if it&apos;s in any of the paths gathered, but just in case you can edit it afterwards. After you have generated and saved it, please click the button below or go to &lt;a href=&quot;https://mgba.io/i/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#2980b9;&quot;&gt;mgba.io/i&lt;/span&gt;&lt;/a&gt; to file the bug report on GitHub. Make sure to attach the report you generated!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt; &lt;head/&gt; &lt;body&gt; &lt;p&gt; Per presentare una segnalazione di bug, generare innanzitutto un file di report da allegare alla segnalazione di bug che si sta per presentare. Si consiglia di includere i file di salvataggio, poiché spesso aiutano con i problemi di debug. Verranno raccolte alcune informazioni sulla versione di {projectName} in esecuzione, sulla configurazione, sul computer e sul gioco attualmente aperto (se presente). Una volta completata questa raccolta è possibile esaminare tutte le informazioni raccolte di seguito e salvarle in un file zip. La raccolta tenterà automaticamente di redigere qualsiasi informazione personale, ad esempio il tuo nome utente se si trova in uno dei percorsi raccolti, ma nel caso in cui tu possa modificarla in seguito. Dopo averlo generato e salvato, fare clic sul pulsante sottostante o passare a &lt;a href=&quot;https://mgba.io/i/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#2980b9;&quot;&gt;mgba.io/i&lt;/span&gt;&lt;/a&gt; per presentare la segnalazione di bug su GitHub. Assicurarsi di allegare il report generato! &lt;/p&gt; &lt;/body&gt; &lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="85"/>
        <source>Generate report</source>
        <translation>Genera rapporto</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="99"/>
        <source>Save</source>
        <translation>Salva</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="113"/>
        <source>Open issue list in browser</source>
        <translation>Apri l&apos;elenco dei problemi nel browser</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="134"/>
        <source>Include save file</source>
        <translation>Includi file di salvataggio</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="150"/>
        <source>Create and include savestate</source>
        <translation>Creare e includere lo stato di salvataggio</translation>
    </message>
</context>
<context>
    <name>QGBA::SaveConverter</name>
    <message>
        <location filename="../SaveConverter.cpp" line="39"/>
        <source>Save games and save states (%1)</source>
        <translation>Salvataggi e stati di salvataggio dei giochi (%1)</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="40"/>
        <source>Select save game or save state</source>
        <translation>Seleziona salvataggio o stato di salvataggio</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="52"/>
        <source>Save games (%1)</source>
        <translation>Salvataggi (%1)</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="53"/>
        <source>Select save game</source>
        <translation>Seleziona salvataggio</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="74"/>
        <location filename="../SaveConverter.cpp" line="85"/>
        <source>Conversion failed</source>
        <translation>Conversione fallita</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="74"/>
        <source>Failed to convert the save game. This is probably a bug.</source>
        <translation>Impossibile convertire il salvataggio. Molto probabilmente è dovuto ad un bug.</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="85"/>
        <source>Failed to open output file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="96"/>
        <source>No file selected</source>
        <translation>Nessun file selezionato</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="103"/>
        <source>Could not open file</source>
        <translation>Non è stato possibile aprire il file</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="118"/>
        <source>No valid formats found</source>
        <translation>Nessun formato valido trovato</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="126"/>
        <source>Please select a valid input file</source>
        <translation>Si prega di selezionare un file di input valido</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="137"/>
        <source>No valid conversions found</source>
        <translation>Nessune conversioni valide trovate</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="666"/>
        <source>Cannot convert save games between platforms</source>
        <translation>Impossibile convertire salvataggi tra piattaforme</translation>
    </message>
    <message>
        <location filename="../SaveConverter.ui" line="14"/>
        <source>Convert/Extract Save Game</source>
        <translation>Converti/Estrai Salvataggio</translation>
    </message>
    <message>
        <location filename="../SaveConverter.ui" line="20"/>
        <source>Input file</source>
        <translation>File input</translation>
    </message>
    <message>
        <location filename="../SaveConverter.ui" line="29"/>
        <location filename="../SaveConverter.ui" line="55"/>
        <source>Browse</source>
        <translation>Sfoglia</translation>
    </message>
    <message>
        <location filename="../SaveConverter.ui" line="46"/>
        <source>Output file</source>
        <translation>File output</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="461"/>
        <source>%1 %2 save game</source>
        <translation>%1 %2 salvataggio</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="465"/>
        <source>little endian</source>
        <translation>little endian</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="468"/>
        <source>big endian</source>
        <translation>big endian</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="479"/>
        <source>SRAM</source>
        <translation>SRAM</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="483"/>
        <source>%1 flash</source>
        <translation>%1 flash</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="487"/>
        <source>%1 EEPROM</source>
        <translation>%1 EEPROM</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="493"/>
        <source> + RTC</source>
        <translation> + RTC</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="502"/>
        <source>%1 SRAM + RTC</source>
        <translation>%1 SRAM + OTR</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="504"/>
        <source>%1 SRAM</source>
        <translation>%1 SRAM</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="509"/>
        <source>packed MBC2</source>
        <translation>MBC2 compresso</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="511"/>
        <source>unpacked MBC2</source>
        <translation>MBC2 non compresso</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="516"/>
        <source>MBC6 flash</source>
        <translation>MBC6 flash</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="518"/>
        <source>MBC6 combined SRAM + flash</source>
        <translation>MBC6 combinato con la SRAM + flash</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="520"/>
        <source>MBC6 SRAM</source>
        <translation>SRAM MBC6</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="524"/>
        <source>TAMA5</source>
        <translation>TAMA5</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="536"/>
        <source>%1 (%2)</source>
        <translation>%1 (%2)</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="540"/>
        <source>%1 save state with embedded %2 save game</source>
        <translation>%1 stato di salvataggio incorporato con il salvataggio %2</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="543"/>
        <source>%1 SharkPort %2 save game</source>
        <translation>%1 SharkPort %2 salvataggio gioco</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="546"/>
        <source>%1 GameShark Advance SP %2 save game</source>
        <translation>%1 GameShark Advance SP %2 salvataggio gioco</translation>
    </message>
</context>
<context>
    <name>QGBA::ScriptingController</name>
    <message>
        <location filename="../scripting/ScriptingController.cpp" line="281"/>
        <source>Lua scripts (*.lua)</source>
        <translation>Script Lua (*.lua)</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingController.cpp" line="283"/>
        <source>All files (*.*)</source>
        <translation>Tutti i file (*.*)</translation>
    </message>
</context>
<context>
    <name>QGBA::ScriptingTextBuffer</name>
    <message>
        <location filename="../scripting/ScriptingTextBuffer.cpp" line="45"/>
        <source>Untitled buffer</source>
        <translation>Buffer senza nome</translation>
    </message>
</context>
<context>
    <name>QGBA::ScriptingView</name>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="14"/>
        <source>Scripting</source>
        <translation>Scripting</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="71"/>
        <source>Run</source>
        <translation>Esegui</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="92"/>
        <source>File</source>
        <translation>File</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="96"/>
        <source>Load recent script</source>
        <translation>Carica script recente</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="108"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="118"/>
        <source>Load script...</source>
        <translation>Carica script...</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="123"/>
        <source>&amp;Load most recent</source>
        <translation>&amp;Carica il più recente</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="128"/>
        <source>&amp;Reset</source>
        <translation>&amp;Ripristina</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="133"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="138"/>
        <source>Edit autorun scripts...</source>
        <translation>Modifica script autorun...</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="143"/>
        <source>Clear console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.cpp" line="67"/>
        <source>Select script to load</source>
        <translation>Selezionare lo script da caricare</translation>
    </message>
</context>
<context>
    <name>QGBA::SensorView</name>
    <message>
        <location filename="../SensorView.ui" line="20"/>
        <source>Sensors</source>
        <translation>Sensori</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="31"/>
        <source>Realtime clock</source>
        <translation>Orologio in tempo reale</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="50"/>
        <source>Fixed time</source>
        <translation>Ora fissa</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="37"/>
        <source>System time</source>
        <translation>Ora del sistema</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="96"/>
        <source>Start time at</source>
        <translation>Avvia ora alle</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="60"/>
        <source>Now</source>
        <translation>Adesso</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="67"/>
        <source>Offset time</source>
        <translation>Tempo di sfasamento</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="80"/>
        <source> sec</source>
        <translation> sec</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="126"/>
        <source>MM/dd/yy hh:mm:ss AP</source>
        <translation>dd/MM/yy HH:mm:ss</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="136"/>
        <source>Light sensor</source>
        <translation>Sensore di luce</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="142"/>
        <source>Brightness</source>
        <translation>Luminosità</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="179"/>
        <source>Tilt sensor</source>
        <translation>Sensore di inclinazione</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="187"/>
        <location filename="../SensorView.ui" line="276"/>
        <source>Set Y</source>
        <translation>Config. Y</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="197"/>
        <location filename="../SensorView.ui" line="286"/>
        <source>Set X</source>
        <translation>Config. X</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="268"/>
        <source>Gyroscope</source>
        <translation>Giroscopio</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="296"/>
        <source>Sensitivity</source>
        <translation>Sensibilità</translation>
    </message>
</context>
<context>
    <name>QGBA::SettingsView</name>
    <message>
        <location filename="../SettingsView.cpp" line="158"/>
        <location filename="../SettingsView.cpp" line="233"/>
        <source>Qt Multimedia</source>
        <translation>Qt Multimedia</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="165"/>
        <source>SDL</source>
        <translation>SDL</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="173"/>
        <source>Software (Qt)</source>
        <translation>Software (Qt)</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1315"/>
        <location filename="../SettingsView.cpp" line="179"/>
        <source>OpenGL</source>
        <translation>OpenGL</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="186"/>
        <source>OpenGL (force version 1.x)</source>
        <translation>OpenGL (forza la versione 1.x)</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="219"/>
        <source>None</source>
        <translation>Nessuno</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="226"/>
        <source>None (Still Image)</source>
        <translation>nessuno (immagine fissa)</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="335"/>
        <source>Keyboard</source>
        <translation>Tastiera</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="347"/>
        <source>Controllers</source>
        <translation>Controller</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="412"/>
        <source>Shortcuts</source>
        <translation>Scorciatoie</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="415"/>
        <source>Shaders are not supported when the display driver is not OpenGL.

If it is set to OpenGL and you still see this, your graphics card or drivers may be too old.</source>
        <translation>Gli shader non sono supportati quando il driver della scheda video non è OpenGL.

Se è impostato su OpenGL e continui a vedere questo messaggio, la tua scheda grafica o i tuoi driver potrebbero essere troppo vecchi.</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="419"/>
        <location filename="../SettingsView.cpp" line="433"/>
        <location filename="../SettingsView.cpp" line="446"/>
        <location filename="../SettingsView.cpp" line="448"/>
        <source>Shaders</source>
        <translation>Shader</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="469"/>
        <source>Select BIOS</source>
        <translation>Seleziona BIOS</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="476"/>
        <source>Select directory</source>
        <translation>Seleziona directory</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="484"/>
        <source>Select image</source>
        <translation>Seleziona immagine</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="484"/>
        <source>Image file (*.png *.jpg *.jpeg)</source>
        <translation>File immagine (*.png *.jpg *.jpeg)</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="878"/>
        <source>(%1×%2)</source>
        <translation>(%1×%2)</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="896"/>
        <source>Never</source>
        <translation>Mai</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="901"/>
        <source>Just now</source>
        <translation>Proprio adesso</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="905"/>
        <source>Less than an hour ago</source>
        <translation>Meno di un&apos;ora fa</translation>
    </message>
    <message numerus="yes">
        <location filename="../SettingsView.cpp" line="910"/>
        <source>%n hour(s) ago</source>
        <translation>
            <numerusform>%n ora fa</numerusform>
            <numerusform>%n ore fa</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../SettingsView.cpp" line="914"/>
        <source>%n day(s) ago</source>
        <translation>
            <numerusform>%n giorno fa</numerusform>
            <numerusform>%n giorni fa</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="20"/>
        <source>Settings</source>
        <translation>Impostazioni</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="45"/>
        <source>Audio/Video</source>
        <translation>Audio/Video</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="50"/>
        <source>Gameplay</source>
        <translation>In gioco</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="55"/>
        <source>Interface</source>
        <translation>Interfaccia</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="60"/>
        <source>Update</source>
        <translation>Aggiornamento</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="65"/>
        <source>Emulation</source>
        <translation>Emulazione</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="70"/>
        <source>Enhancements</source>
        <translation>Miglioramenti</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="80"/>
        <source>Paths</source>
        <translation>Cartelle</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="85"/>
        <source>Logging</source>
        <translation>Registrazione</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="90"/>
        <source>Game Boy</source>
        <translation>Game Boy</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="111"/>
        <source>Audio driver:</source>
        <translation>Driver audio:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="128"/>
        <source>Audio buffer:</source>
        <translation>Buffer audio:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="140"/>
        <location filename="../SettingsView.ui" line="162"/>
        <source>1536</source>
        <translation>1536</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="147"/>
        <source>512</source>
        <translation>512</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="152"/>
        <source>768</source>
        <translation>768</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="157"/>
        <source>1024</source>
        <translation>1024</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="167"/>
        <source>2048</source>
        <translation>2048</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="172"/>
        <source>3072</source>
        <translation>3072</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="177"/>
        <source>4096</source>
        <translation>4096</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="185"/>
        <source>samples</source>
        <translation>campioni</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="194"/>
        <source>Sample rate:</source>
        <translation>Freq. di campionamento:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="206"/>
        <location filename="../SettingsView.ui" line="223"/>
        <source>44100</source>
        <translation>44100</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="213"/>
        <source>22050</source>
        <translation>22050</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="218"/>
        <source>32000</source>
        <translation>32000</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="228"/>
        <source>48000</source>
        <translation>48000</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="236"/>
        <source>Hz</source>
        <translation>Hz</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="245"/>
        <source>Volume:</source>
        <translation>Volume:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="276"/>
        <location filename="../SettingsView.ui" line="316"/>
        <location filename="../SettingsView.ui" line="811"/>
        <location filename="../SettingsView.ui" line="836"/>
        <source>Mute</source>
        <translation>Muto</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="285"/>
        <source>Fast forward volume:</source>
        <translation>Volume modalità accelerata:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="325"/>
        <source>Audio in multiplayer:</source>
        <translation>Audio nel multiplayer:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="332"/>
        <source>All windows</source>
        <translation>Tutte le finestre</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="345"/>
        <source>Player 1 window only</source>
        <translation>Solo finestra giocatore 1</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="355"/>
        <source>Currently active player window</source>
        <translation>Finestra giocatore attualmente attiva</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="388"/>
        <source>Display driver:</source>
        <translation>Driver schermo:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="405"/>
        <source>Frameskip:</source>
        <translation>Salto frame:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="414"/>
        <source>Skip every</source>
        <translation>Salta ogni</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="424"/>
        <location filename="../SettingsView.ui" line="1199"/>
        <source>frames</source>
        <translation>frame</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="475"/>
        <source>FPS target:</source>
        <translation>FPS finali:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="500"/>
        <source>frames per second</source>
        <translation>frame al secondo</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="516"/>
        <source>Sync:</source>
        <translation>Sincronizza:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="382"/>
        <location filename="../SettingsView.ui" line="525"/>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="105"/>
        <location filename="../SettingsView.ui" line="532"/>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="433"/>
        <source>Lock aspect ratio</source>
        <translation>Blocca rapporti aspetto</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="757"/>
        <source>Show filename instead of ROM name in library view</source>
        <translation>Mostra nome del file al posto del nome della ROM nella visualizzazione libreria</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="804"/>
        <location filename="../SettingsView.ui" line="829"/>
        <source>Pause</source>
        <translation>Pausa</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="795"/>
        <source>When inactive:</source>
        <translation>Quando inattiva:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="548"/>
        <source>On loading a game:</source>
        <translation>Al caricamento del gioco:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="555"/>
        <source>Load last state</source>
        <translation>Carica l&apos;ultimo stato</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="565"/>
        <source>Load cheats</source>
        <translation>Carica trucchi</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="575"/>
        <source>Edit autorun scripts</source>
        <translation>Modifica script autorun</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="599"/>
        <source>Save entered cheats</source>
        <translation>Salva i trucchi inseriti</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="820"/>
        <source>When minimized:</source>
        <translation>Quando rimpicciolita:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="904"/>
        <source>Show frame count in OSD</source>
        <translation>Mostra contatore frame nell&apos;OSD</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="911"/>
        <source>Show emulation info on reset</source>
        <translation>Mostra informazioni emulazione su reset</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="948"/>
        <source>Custom border:</source>
        <translation>Bordo personalizzato:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="959"/>
        <source>Current channel:</source>
        <translation>Canale attuale:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="973"/>
        <source>Current version:</source>
        <translation>Versione attuale:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="997"/>
        <source>Update channel:</source>
        <translation>Canale aggiornamento:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1007"/>
        <source>Available version:</source>
        <translation>Versione disponibile:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1014"/>
        <source>(Unknown)</source>
        <translation>(Sconosciuto)</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1024"/>
        <source>Last checked:</source>
        <translation>Ultimo controllo:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1045"/>
        <source>Automatically check on start</source>
        <translation>Verifica automaticamente all&apos;avvio</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1052"/>
        <source>Check now</source>
        <translation>Verifica adesso</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1208"/>
        <source>Rewind speed:</source>
        <translation>Velocità riavvolgimento:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1815"/>
        <source>Models</source>
        <translation>Modelli</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1821"/>
        <source>GB only:</source>
        <translation>Solo GB:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1831"/>
        <source>SGB compatible:</source>
        <translation>Compatibile SGB:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1841"/>
        <source>GBC only:</source>
        <translation>Solo GBC:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1851"/>
        <source>GBC compatible:</source>
        <translation>Compatibile GBC:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1861"/>
        <source>SGB and GBC compatible:</source>
        <translation>Compatibile SGB e GBC:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1881"/>
        <source>Game Boy palette</source>
        <translation>Tavolozza Game Boy</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2174"/>
        <source>Default color palette only</source>
        <translation>Solo tavolozza colori predefinita</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2167"/>
        <source>SGB color palette if available</source>
        <translation>Tavolozza colori SGB se disponibile</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2181"/>
        <source>GBC color palette if available</source>
        <translation>Tavolozza colori GBC se disponibile</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2188"/>
        <source>SGB (preferred) or GBC color palette if available</source>
        <translation>Tavolozza colori SGB (preferita) o GBC se disponibile</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2200"/>
        <source>Game Boy Camera</source>
        <translation>Videocamera Game Boy</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2206"/>
        <source>Driver:</source>
        <translation>Driver:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2223"/>
        <source>Source:</source>
        <translation>Sorgente:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="509"/>
        <source>Native (59.7275)</source>
        <translation>Nativi (59.7275)</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="447"/>
        <source>Interframe blending</source>
        <translation>Miscelazione dei frame</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="852"/>
        <source>Dynamically update window title</source>
        <translation>Aggiorna dinamicamente il titolo della finestra</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="698"/>
        <source>Enable Discord Rich Presence</source>
        <translation>Abilita Discord Rich Presence</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="616"/>
        <source>Save state extra data:</source>
        <translation>Dati extra stato di salvataggio:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="633"/>
        <location filename="../SettingsView.ui" line="677"/>
        <source>Save game</source>
        <translation>Salvataggio</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="660"/>
        <source>Load state extra data:</source>
        <translation>Carica dati extra stato di salvataggio:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1288"/>
        <source>Enable VBA bug compatibility in ROM hacks</source>
        <translation>Abilita compatibilità con i bug di VBA nelle hack delle ROM</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1887"/>
        <source>Preset:</source>
        <translation>Profilo:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="889"/>
        <source>Show OSD messages</source>
        <translation>Mostra messaggi OSD</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="589"/>
        <source>Periodically autosave state</source>
        <translation>Salva periodicamente in automatico lo stato</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="872"/>
        <source>Show filename instead of ROM name in title bar</source>
        <translation>Mostra nome file anziché nome ROM nella barra del titolo</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1109"/>
        <source>Fast forward (held) speed:</source>
        <translation>Velocità di crociera:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1281"/>
        <source>Enable Game Boy Player features by default</source>
        <translation>Abilita funzionalità Game Boy Player per impostazione predefinita</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1302"/>
        <source>Video renderer:</source>
        <translation>Rend. video:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1310"/>
        <source>Software</source>
        <translation>Software</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1323"/>
        <source>OpenGL enhancements</source>
        <translation>Miglioramenti OpenGL</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1329"/>
        <source>High-resolution scale:</source>
        <translation>Rapporto alta risoluzione:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1367"/>
        <source>(240×160)</source>
        <translation>(240×160)</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1724"/>
        <source>Cheats</source>
        <translation>Trucchi</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1781"/>
        <source>Log to file</source>
        <translation>Registro salvato su file</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1788"/>
        <source>Log to console</source>
        <translation>Registro mostrato in console</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1802"/>
        <source>Select Log File</source>
        <translation>Seleziona file registro</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1897"/>
        <source>Default BG colors:</source>
        <translation>Colori predefiniti sfondo:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1871"/>
        <source>Super Game Boy borders</source>
        <translation>Bordi Super Game Boy</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1984"/>
        <source>Default sprite colors 1:</source>
        <translation>Colori predefiniti sprite 1:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2071"/>
        <source>Default sprite colors 2:</source>
        <translation>Colori predefiniti sprite 2:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="726"/>
        <source>Library:</source>
        <translation>Libreria:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="747"/>
        <source>Show when no game open</source>
        <translation>Mostra quando nessun gioco è aperto</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="764"/>
        <source>Clear cache</source>
        <translation>Svuota la cache</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1066"/>
        <source>Fast forward speed:</source>
        <translation>Velocità di avanzamento rapido:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="932"/>
        <location filename="../SettingsView.ui" line="1415"/>
        <location filename="../SettingsView.ui" line="1443"/>
        <location filename="../SettingsView.ui" line="1471"/>
        <location filename="../SettingsView.ui" line="1499"/>
        <location filename="../SettingsView.ui" line="1557"/>
        <location filename="../SettingsView.ui" line="1605"/>
        <location filename="../SettingsView.ui" line="1653"/>
        <location filename="../SettingsView.ui" line="1701"/>
        <location filename="../SettingsView.ui" line="1749"/>
        <source>Browse</source>
        <translation>Sfoglia</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1508"/>
        <source>Use BIOS file if found</source>
        <translation>Usa il file del BIOS se è presente</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1518"/>
        <source>Skip BIOS intro</source>
        <translation>Salta intro del BIOS</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1097"/>
        <location filename="../SettingsView.ui" line="1140"/>
        <source>Unbounded</source>
        <translation>Illimitato</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="785"/>
        <source>Suspend screensaver</source>
        <translation>Sospendi salvaschermo</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="75"/>
        <source>BIOS</source>
        <translation>BIOS</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1253"/>
        <source>Run all</source>
        <translation>esegui tutto</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1258"/>
        <source>Remove known</source>
        <translation>rimuovi conosciuti</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1263"/>
        <source>Detect and remove</source>
        <translation>rileva e rimuovi</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="778"/>
        <source>Allow opposing input directions</source>
        <translation>Consenti direzioni opposte</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="623"/>
        <location filename="../SettingsView.ui" line="667"/>
        <source>Screenshot</source>
        <translation>Schermata</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="643"/>
        <location filename="../SettingsView.ui" line="684"/>
        <source>Cheat codes</source>
        <translation>Trucchi</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1176"/>
        <source>Enable rewind</source>
        <translation>Abilita riavvolgimento</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="454"/>
        <source>Bilinear filtering</source>
        <translation>Filtro bilineare</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="440"/>
        <source>Force integer scaling</source>
        <translation>Forza ridimensionamento a interi</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="709"/>
        <source>Language</source>
        <translation>Lingua</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="734"/>
        <source>List view</source>
        <translation>lista a elenco</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="739"/>
        <source>Tree view</source>
        <translation>vista ad albero</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="862"/>
        <source>Show FPS in title bar</source>
        <translation>Mostra gli FPS nella barra del titolo</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1183"/>
        <source>Rewind history:</source>
        <translation>Cronologia riavvolgimento:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1245"/>
        <source>Idle loops:</source>
        <translation>Cicli inattivi:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1271"/>
        <source>Preload entire ROM into memory</source>
        <translation>Precarica ROM in memoria</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1152"/>
        <source>Autofire interval:</source>
        <translation>Intervallo Autofire:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1396"/>
        <source>GB BIOS file:</source>
        <translation>File BIOS del GB:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1480"/>
        <source>GBA BIOS file:</source>
        <translation>File BIOS del GBA:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1452"/>
        <source>GBC BIOS file:</source>
        <translation>File BIOS del GBC:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1424"/>
        <source>SGB BIOS file:</source>
        <translation>File BIOS del SGB:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1532"/>
        <source>Save games</source>
        <translation>Salva le partite</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1566"/>
        <location filename="../SettingsView.ui" line="1614"/>
        <location filename="../SettingsView.ui" line="1662"/>
        <location filename="../SettingsView.ui" line="1710"/>
        <location filename="../SettingsView.ui" line="1758"/>
        <source>Same directory as the ROM</source>
        <translation>Stessa cartella della ROM</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1580"/>
        <source>Save states</source>
        <translation>Salvataggio Stati</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1628"/>
        <source>Screenshots</source>
        <translation>Schermate</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1676"/>
        <source>Patches</source>
        <translation>Patch</translation>
    </message>
</context>
<context>
    <name>QGBA::ShaderSelector</name>
    <message>
        <location filename="../ShaderSelector.cpp" line="78"/>
        <source>No shader active</source>
        <translation>Nessuno shader attivo</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="92"/>
        <location filename="../ShaderSelector.cpp" line="95"/>
        <source>Load shader</source>
        <translation>Carica shader</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="94"/>
        <source>mGBA Shaders</source>
        <translation>Shader mGBA</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="125"/>
        <source>Error loading shader</source>
        <translation>Errore caricamento shader</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="125"/>
        <source>The shader &quot;%1&quot; could not be loaded successfully.</source>
        <translation>Impossibile caricare lo shader &quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="147"/>
        <source>No shader loaded</source>
        <translation>Nessuno shader caricato</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="155"/>
        <source>by %1</source>
        <translation>di %1</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="166"/>
        <source>Preprocessing</source>
        <translation>Pre-elaborazione</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="173"/>
        <source>Pass %1</source>
        <translation>Pass %1</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="14"/>
        <source>Shaders</source>
        <translation>Shader</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="28"/>
        <source>Active Shader:</source>
        <translation>Attiva Shader:</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="35"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="45"/>
        <source>Author</source>
        <translation>Autore</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="62"/>
        <source>Description</source>
        <translation>Descrizione</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="88"/>
        <source>Unload Shader</source>
        <translation>Non caricare shader</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="95"/>
        <source>Load New Shader</source>
        <translation>Carica nuovo shader</translation>
    </message>
</context>
<context>
    <name>QGBA::ShortcutModel</name>
    <message>
        <location filename="../ShortcutModel.cpp" line="68"/>
        <source>Action</source>
        <translation>Azione</translation>
    </message>
    <message>
        <location filename="../ShortcutModel.cpp" line="70"/>
        <source>Keyboard</source>
        <translation>Tastiera</translation>
    </message>
    <message>
        <location filename="../ShortcutModel.cpp" line="72"/>
        <source>Gamepad</source>
        <translation>Gamepad</translation>
    </message>
</context>
<context>
    <name>QGBA::ShortcutView</name>
    <message>
        <location filename="../ShortcutView.ui" line="14"/>
        <source>Edit Shortcuts</source>
        <translation>Modifica le Scorciatoie</translation>
    </message>
    <message>
        <location filename="../ShortcutView.ui" line="32"/>
        <source>Keyboard</source>
        <translation>Tastiera</translation>
    </message>
    <message>
        <location filename="../ShortcutView.ui" line="42"/>
        <source>Gamepad</source>
        <translation>Gamepad</translation>
    </message>
    <message>
        <location filename="../ShortcutView.ui" line="49"/>
        <source>Clear</source>
        <translation>Svuota</translation>
    </message>
</context>
<context>
    <name>QGBA::TileView</name>
    <message>
        <location filename="../TileView.cpp" line="227"/>
        <source>Export tiles</source>
        <translation>Esporta Tile</translation>
    </message>
    <message>
        <location filename="../TileView.cpp" line="228"/>
        <location filename="../TileView.cpp" line="240"/>
        <source>Portable Network Graphics (*.png)</source>
        <translation>Portable Network Graphics (*.png)</translation>
    </message>
    <message>
        <location filename="../TileView.cpp" line="239"/>
        <source>Export tile</source>
        <translation>Esporta tile</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="14"/>
        <source>Tiles</source>
        <translation>Tiles</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="170"/>
        <source>Export Selected</source>
        <translation>Esporta Selezionato</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="184"/>
        <source>Export All</source>
        <translation>Esporta tutto</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="40"/>
        <source>256 colors</source>
        <translation>256 colori</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="33"/>
        <source>Palette</source>
        <translation>Tavolozza</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="73"/>
        <source>Magnification</source>
        <translation>Ingrandimento</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="96"/>
        <source>Tiles per row</source>
        <translation>Tile per riga</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="103"/>
        <source>Fit to window</source>
        <translation>Adatta finestra</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="119"/>
        <source>Displayed tiles</source>
        <translation>Tile visualizzati</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="125"/>
        <source>Only BG tiles</source>
        <translation>Solo tile BG</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="135"/>
        <source>Only OBJ tiles</source>
        <translation>Solo tile OBJ</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="145"/>
        <source>Both</source>
        <translation>Entrambi</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="163"/>
        <source>Copy Selected</source>
        <translation>Copia selezionati</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="177"/>
        <source>Copy All</source>
        <translation>Copia tutto</translation>
    </message>
</context>
<context>
    <name>QGBA::VideoView</name>
    <message>
        <location filename="../VideoView.cpp" line="224"/>
        <source>Failed to open output video file: %1</source>
        <translation>Errore durante l&apos;archiviazione del video: %1</translation>
    </message>
    <message>
        <location filename="../VideoView.cpp" line="245"/>
        <source>Native (%0x%1)</source>
        <translation>Nativo (%0x%1)</translation>
    </message>
    <message>
        <location filename="../VideoView.cpp" line="260"/>
        <source>Select output file</source>
        <translation>Seleziona file di uscita</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="20"/>
        <source>Record Video</source>
        <translation>Registra Video</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="40"/>
        <source>Start</source>
        <translation>Avvia</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="56"/>
        <source>Stop</source>
        <translation>Ferma</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="69"/>
        <source>Select File</source>
        <translation>Seleziona File</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="101"/>
        <source>Presets</source>
        <translation>Profili</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="129"/>
        <source>WebM</source>
        <translation>WebM</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="240"/>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="139"/>
        <source>MP4</source>
        <translation>MP4</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="109"/>
        <source>High &amp;Quality</source>
        <translation>Alta qualità</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="119"/>
        <source>&amp;YouTube</source>
        <translation>&amp;YouTube</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="146"/>
        <source>&amp;Lossless</source>
        <translation>&amp;Lossless</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="167"/>
        <source>4K</source>
        <translation>4K</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="174"/>
        <source>&amp;1080p</source>
        <translation>&amp;1080p</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="184"/>
        <source>&amp;720p</source>
        <translation>&amp;720p</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="194"/>
        <source>&amp;480p</source>
        <translation>&amp;480p</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="207"/>
        <source>&amp;Native</source>
        <translation>&amp;Nativa</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="375"/>
        <source> Bitrate (kbps)</source>
        <translation> Bitrate (kbps)</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="420"/>
        <source>ABR</source>
        <translation>ABR</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="465"/>
        <source>VBR</source>
        <translation>VBR</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="478"/>
        <source>CRF</source>
        <translation>CRF</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="494"/>
        <source>Dimensions</source>
        <translation>Dimensioni</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="560"/>
        <source>Lock aspect ratio</source>
        <translation>Blocca rapporti aspetto</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="575"/>
        <source>Show advanced</source>
        <translation>Mostra avanzate</translation>
    </message>
</context>
<context>
    <name>QGBA::Window</name>
    <message>
        <location filename="../Window.cpp" line="354"/>
        <source>Archives (%1)</source>
        <translation>Archivi (%1)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="359"/>
        <location filename="../Window.cpp" line="375"/>
        <location filename="../Window.cpp" line="402"/>
        <source>Select ROM</source>
        <translation>Seleziona ROM</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="537"/>
        <location filename="../Window.cpp" line="544"/>
        <source>Select save</source>
        <translation>Seleziona salvataggio</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="449"/>
        <source>Select patch</source>
        <translation>Seleziona patch</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="449"/>
        <source>Patches (*.ips *.ups *.bps)</source>
        <translation>Patch (*.ips *.ups *.bps)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="460"/>
        <source>Select e-Reader dotcode</source>
        <translation>Selezione e-Reader dotcode</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="460"/>
        <source>e-Reader card (*.raw *.bin *.bmp)</source>
        <translation>Scheda e-Reader (*.raw *.bin *.bmp)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="468"/>
        <source>Select e-Reader card images</source>
        <translation>Seleziona immagini carte e-Reader</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="468"/>
        <source>Image file (*.png *.jpg *.jpeg)</source>
        <translation>File immagine (*.png *.jpg *.jpeg)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="469"/>
        <source>Conversion finished</source>
        <translation>Conversione terminata</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="510"/>
        <source>%1 of %2 e-Reader cards converted successfully.</source>
        <translation>%1 di %2 carte e-Reader convertite con successo.</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="530"/>
        <source>Select image</source>
        <translation>Seleziona immagine</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="530"/>
        <source>Image file (*.png *.gif *.jpg *.jpeg);;All files (*)</source>
        <translation>File immagine (*.png *.gif *.jpg *.jpeg);;Tutti i file (*)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="544"/>
        <source>GameShark saves (*.sps *.xps)</source>
        <translation>Salvataggi GameShark (*.sps *.xps)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="583"/>
        <source>Select video log</source>
        <translation>Seleziona registro video</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="583"/>
        <source>Video logs (*.mvl)</source>
        <translation>Registro video (*.mvl)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1040"/>
        <source>Crash</source>
        <translation>Errore fatale</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1041"/>
        <source>The game has crashed with the following error:

%1</source>
        <translation>Il gioco è andato in crash con il seguente errore::

%1</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1063"/>
        <source>Unimplemented BIOS call</source>
        <translation>BIOS non implementato</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1064"/>
        <source>This game uses a BIOS call that is not implemented. Please use the official BIOS for best experience.</source>
        <translation>Questo gioco utilizza una chiamata BIOS non implementata. Utilizza il BIOS ufficiale per una migliore esperienza.</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1086"/>
        <source>Failed to create an appropriate display device, falling back to software display. Games may run slowly, especially with larger windows.</source>
        <translation>Impossibile creare un dispositivo di visualizzazione appropriato, tornando alla visualizzazione software. I giochi possono funzionare lentamente, specialmente con finestre più grandi.</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1187"/>
        <source>Really make portable?</source>
        <translation>Vuoi davvero rendere portatile l&apos;applicazione?</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1188"/>
        <source>This will make the emulator load its configuration from the same directory as the executable. Do you want to continue?</source>
        <translation>In questo modo l&apos;emulatore carica la propria configurazione dalla stessa cartella dell&apos;eseguibile. Vuoi continuare?</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1200"/>
        <source>Restart needed</source>
        <translation>È necessario riavviare</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1201"/>
        <source>Some changes will not take effect until the emulator is restarted.</source>
        <translation>Alcune modifiche non avranno effetto finché l&apos;emulatore non verrà riavviato.</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1252"/>
        <source> -  Player %1 of %2</source>
        <translation> -  Giocatore %1 di %2</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1263"/>
        <source>%1 - %2</source>
        <translation>%1 - %2</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1265"/>
        <source>%1 - %2 - %3</source>
        <translation>%1 - %2 - %3</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1267"/>
        <source>%1 - %2 (%3 fps) - %4</source>
        <translation>%1 - %2 (%3 fps) - %4</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1331"/>
        <source>&amp;File</source>
        <translation>File</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1333"/>
        <source>Load &amp;ROM...</source>
        <translation>Carica ROM...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1336"/>
        <source>Load ROM in archive...</source>
        <translation>Carica la ROM in archivio...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1377"/>
        <source>Load &amp;patch...</source>
        <translation>Carica patch...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1380"/>
        <source>Boot BIOS</source>
        <translation>Avvia BIOS</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1474"/>
        <source>Replace ROM...</source>
        <translation>Sostituisci la ROM...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1384"/>
        <source>Scan e-Reader dotcodes...</source>
        <translation>Scansiona e-Reader dotcode...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1825"/>
        <source>Convert e-Reader card image to raw...</source>
        <translation>Converti immagini carte e-Reader in raw...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1388"/>
        <source>ROM &amp;info...</source>
        <translation>Informazioni ROM...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1390"/>
        <source>Recent</source>
        <translation>Recenti</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1790"/>
        <source>Make portable</source>
        <translation>Rendi portatile</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1393"/>
        <source>&amp;Load state</source>
        <translation>Carica stato</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1403"/>
        <source>&amp;Save state</source>
        <translation>Salva stato</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1413"/>
        <source>Quick load</source>
        <translation>Caricamento rapido</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1414"/>
        <source>Quick save</source>
        <translation>Salvataggio rapido</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1416"/>
        <source>Load recent</source>
        <translation>Carica recente</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1421"/>
        <source>Save recent</source>
        <translation>Salva recente</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1429"/>
        <source>Undo load state</source>
        <translation>Annulla il caricamento dello stato</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1432"/>
        <source>Undo save state</source>
        <translation>Annulla salvataggio stato</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1439"/>
        <location filename="../Window.cpp" line="1444"/>
        <source>State &amp;%1</source>
        <translation>Stato %1</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1570"/>
        <source>Load camera image...</source>
        <translation>Carica immagine fotocamera...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1350"/>
        <source>Convert save game...</source>
        <translation>Converti salvataggi...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="537"/>
        <source>GameShark saves (*.gsv *.sps *.xps)</source>
        <translation>Salvataggi GameShark (*.gsv *.sps *.xps)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1159"/>
        <source>Failed to start audio processor</source>
        <translation>Impossibile avviare il processore audio</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1212"/>
        <source>Reset needed</source>
        <translation>Reset necessario</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1213"/>
        <source>Some changes will not take effect until the game is reset.</source>
        <translation>Alcune modifiche non si applicheranno finché il gioco non viene resettato.</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1451"/>
        <source>New multiplayer window</source>
        <translation>Nuova finestra multigiocatore</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1454"/>
        <source>Connect to Dolphin...</source>
        <translation>Connessione a Dolphin...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1460"/>
        <source>Report bug...</source>
        <translation>Segnala bug...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1467"/>
        <source>E&amp;xit</source>
        <translation>Esci (&amp;X)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1469"/>
        <source>&amp;Emulation</source>
        <translation>Emulazione</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1470"/>
        <source>&amp;Reset</source>
        <translation>Reset</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1471"/>
        <source>Sh&amp;utdown</source>
        <translation>Spegni (&amp;U)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1475"/>
        <source>Yank game pak</source>
        <translation>Stacca game pak</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1478"/>
        <source>&amp;Pause</source>
        <translation>Pausa</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1487"/>
        <source>&amp;Next frame</source>
        <translation>Salta il prossimo frame (&amp;N)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1491"/>
        <source>Fast forward (held)</source>
        <translation>Avanzamento rapido (tieni premuto)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1497"/>
        <source>&amp;Fast forward</source>
        <translation>Avanzamento rapido (&amp;F)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1501"/>
        <source>Fast forward speed</source>
        <translation>Velocità di avanzamento rapido</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1506"/>
        <source>Unbounded</source>
        <translation>Illimitata</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1510"/>
        <source>%0x</source>
        <translation>%0x</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1514"/>
        <source>Increase fast forward speed</source>
        <translation>Aumenta la velocità di avvolgimento veloce</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1521"/>
        <source>Decrease fast forward speed</source>
        <translation>Diminuisci la velocità di avvolgimento veloce</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1528"/>
        <source>Rewind (held)</source>
        <translation>Riavvolgimento (tieni premuto)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1540"/>
        <source>Re&amp;wind</source>
        <translation>Riavvolgimento (&amp;W)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1545"/>
        <source>Step backwards</source>
        <translation>Torna indietro</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1552"/>
        <source>Solar sensor</source>
        <translation>Sensore solare</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1553"/>
        <source>Increase solar level</source>
        <translation>Incrementa il livello solare</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1554"/>
        <source>Decrease solar level</source>
        <translation>Riduci il livello solare</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1555"/>
        <source>Brightest solar level</source>
        <translation>Livello solare massimo</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1558"/>
        <source>Darkest solar level</source>
        <translation>Livello solare minimo</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1564"/>
        <source>Brightness %1</source>
        <translation>Luminosità %1</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1585"/>
        <source>Audio/&amp;Video</source>
        <translation>Audio/Video</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1586"/>
        <source>Frame size</source>
        <translation>Dimensione frame</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1629"/>
        <source>Toggle fullscreen</source>
        <translation>Abilita schermo Intero</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1632"/>
        <source>&amp;Lock frame size</source>
        <translation>&amp;Blocca dimensione cornice</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1645"/>
        <source>Lock aspect ratio</source>
        <translation>Blocca rapporti aspetto</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1686"/>
        <source>Frame&amp;skip</source>
        <translation>Salto frame</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1699"/>
        <source>Mute</source>
        <translation>Muto</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1706"/>
        <source>FPS target</source>
        <translation>FPS finali</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1729"/>
        <source>Take &amp;screenshot</source>
        <translation>Acquisisci schermata</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1731"/>
        <source>F12</source>
        <translation>F12</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1736"/>
        <source>Record GIF/WebP/APNG...</source>
        <translation>Registra GIF / WebP / APNG ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1740"/>
        <source>Video layers</source>
        <translation>Layers video</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1741"/>
        <source>Audio channels</source>
        <translation>Canali audio</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1747"/>
        <source>Hide &amp;menu</source>
        <translation>Nascondi &amp;menu</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1752"/>
        <source>&amp;Tools</source>
        <translation>Strumenti</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1753"/>
        <source>View &amp;logs...</source>
        <translation>Visualizza registri (&amp;log)...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1755"/>
        <source>Game &amp;overrides...</source>
        <translation>Sovrascrivi funzioni del gioco...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1781"/>
        <source>&amp;Cheats...</source>
        <translation>Trucchi...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1786"/>
        <source>Create forwarder...</source>
        <translation>Crea Icona di avvio...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1794"/>
        <source>Open debugger console...</source>
        <translation>Apri console debugger...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1796"/>
        <source>Start &amp;GDB server...</source>
        <translation>Avvia server GDB...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1789"/>
        <source>Settings...</source>
        <translation>Impostazioni...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="393"/>
        <source>Select folder</source>
        <translation>Seleziona cartella</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1048"/>
        <source>Couldn&apos;t Start</source>
        <translation>Non è stato possibile avviare</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1049"/>
        <source>Could not start game.</source>
        <translation>Non è stato possibile avviare il gioco.</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1337"/>
        <source>Add folder to library...</source>
        <translation>Aggiungi cartella alla libreria...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1398"/>
        <source>Load state file...</source>
        <translation>Carica stato di salvataggio...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1408"/>
        <source>Save state file...</source>
        <translation>Salva stato di salvataggio...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1353"/>
        <source>Import GameShark Save...</source>
        <translation>Importa Salvataggio GameShark...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1356"/>
        <source>Export GameShark Save...</source>
        <translation>Esporta Salvataggio GameShark...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1466"/>
        <source>About...</source>
        <translation>Informazioni…</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1657"/>
        <source>Force integer scaling</source>
        <translation>Forza ridimensionamento a interi</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1678"/>
        <source>Bilinear filtering</source>
        <translation>Filtro bilineare</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1572"/>
        <source>Game Boy Printer...</source>
        <translation>Stampante Game Boy...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="410"/>
        <source>Save games (%1)</source>
        <translation>Salvataggi (%1)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="411"/>
        <source>Select save game</source>
        <translation>Seleziona salvataggio</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="419"/>
        <source>mGBA save state files (%1)</source>
        <translation>file di stati di salvataggio mGBA (%1)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="421"/>
        <location filename="../Window.cpp" line="426"/>
        <source>Select save state</source>
        <translation>Seleziona stato di salvataggio</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1340"/>
        <source>Save games</source>
        <translation>Salvataggi</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1341"/>
        <source>Load alternate save game...</source>
        <translation>Carica stato di salvataggio alternativo...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1344"/>
        <source>Load temporary save game...</source>
        <translation>Carica salvataggio temporaneo...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1363"/>
        <source>Automatically determine</source>
        <translation>Determina automaticamente</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1367"/>
        <source>Use player %0 save game</source>
        <translation>Usa il salvataggio del giocatore %0</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1581"/>
        <source>BattleChip Gate...</source>
        <translation>BattleChip Gate...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1588"/>
        <source>%1×</source>
        <translation>%1x</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1669"/>
        <source>Interframe blending</source>
        <translation>Miscelazione dei frame</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1714"/>
        <source>Native (59.7275)</source>
        <translation>Nativo (59.7)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1735"/>
        <source>Record A/V...</source>
        <translation>Registra A/V...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1743"/>
        <source>Adjust layer placement...</source>
        <translation>Regola posizionamento layer...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1768"/>
        <source>Game Pak sensors...</source>
        <translation>Sensori Game Pak...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1783"/>
        <source>Scripting...</source>
        <translation>Scripting...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1804"/>
        <source>Game state views</source>
        <translation>Viste degli stati del gioco</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1805"/>
        <source>View &amp;palette...</source>
        <translation>Mostra palette...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1806"/>
        <source>View &amp;sprites...</source>
        <translation>Mostra sprites...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1807"/>
        <source>View &amp;tiles...</source>
        <translation>Mostra tiles...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1808"/>
        <source>View &amp;map...</source>
        <translation>Mostra mappa...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1809"/>
        <source>&amp;Frame inspector...</source>
        <translation>&amp;Frame inspector...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1810"/>
        <source>View memory...</source>
        <translation>Mostra memoria...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1811"/>
        <source>Search memory...</source>
        <translation>Ricerca memoria...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1812"/>
        <source>View &amp;I/O registers...</source>
        <translation>Mostra registri I/O...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1815"/>
        <source>Log memory &amp;accesses...</source>
        <translation>Registra memoria &amp;accessi...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1829"/>
        <source>Record debug video log...</source>
        <translation>Salva registro video di debug...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1830"/>
        <source>Stop debug video log</source>
        <translation>Ferma registro video di debug</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1834"/>
        <source>Exit fullscreen</source>
        <translation>Esci da Schermo Intero</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1836"/>
        <source>GameShark Button (held)</source>
        <translation>Pulsante GameShark (tieni premuto)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1842"/>
        <source>Autofire</source>
        <translation>Pulsanti Autofire</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1843"/>
        <source>Autofire A</source>
        <translation>Autofire A</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1848"/>
        <source>Autofire B</source>
        <translation>Autofire B</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1853"/>
        <source>Autofire L</source>
        <translation>Autofire L</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1858"/>
        <source>Autofire R</source>
        <translation>Autofire R</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1863"/>
        <source>Autofire Start</source>
        <translation>Autofire Start</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1868"/>
        <source>Autofire Select</source>
        <translation>Autofire Select</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1873"/>
        <source>Autofire Up</source>
        <translation>Autofire Su</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1878"/>
        <source>Autofire Right</source>
        <translation>AAutofire Destra</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1883"/>
        <source>Autofire Down</source>
        <translation>Autofire Giù</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1888"/>
        <source>Autofire Left</source>
        <translation>Autofire Sinistra</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="2093"/>
        <source>Clear</source>
        <translation>Pulisci</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../utils.cpp" line="26"/>
        <source>%1 byte</source>
        <translation>%1 byte</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="29"/>
        <source>%1 kiB</source>
        <translation>%1 kiB</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="33"/>
        <source>%1 MiB</source>
        <translation>%1 MiB</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="183"/>
        <source>Super (L)</source>
        <translation>Super (L)</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="185"/>
        <source>Super (R)</source>
        <translation>Super (R)</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="187"/>
        <source>Menu</source>
        <translation>Menu</translation>
    </message>
</context>
<context>
    <name>QShortcut</name>
    <message>
        <location filename="../utils.cpp" line="174"/>
        <source>Shift</source>
        <translation>Shift</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="176"/>
        <source>Control</source>
        <translation>Control</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="178"/>
        <source>Alt</source>
        <translation>Alt</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="180"/>
        <source>Meta</source>
        <translation>Meta</translation>
    </message>
</context>
</TS>
