package com.example.gbapocket

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : Activity() {
    private val keys = AtomicInteger(0)
    // libretro joypad IDs: B=0, Select=2, Start=3, Up=4, Down=5,
    // Left=6, Right=7, A=8, L=10, R=11.
    private val gbaButtons = listOf("A", "B", "L", "R", "Start", "Select", "Up", "Down", "Left", "Right")
    private val libretroIds = mapOf("A" to 8, "B" to 0, "L" to 10, "R" to 11,
        "Start" to 3, "Select" to 2, "Up" to 4, "Down" to 5, "Left" to 6, "Right" to 7)
    private val defaultAssignments = gbaButtons.associateWith { it }
    private val activeTouches = mutableMapOf<Pair<Int, Int>, String>()
    private val touchLock = Any()
    private var assignments: Map<String, String> = defaultAssignments

    private lateinit var screen: GameScreen
    @Volatile private var running = false
    private var loaded = false
    private var worker: Thread? = null
    private var gameId = ""
    private var romName = ""
    private var folder: Uri? = null
    private val romPicker = 100
    private val folderPicker = 101
    private val importPicker = 102
    private val prefs by lazy { getSharedPreferences("gbapocket", MODE_PRIVATE) }
    private val saveDir get() = File(filesDir, "Saves").apply { mkdirs() }
    private val stateDir get() = File(filesDir, "States").apply { mkdirs() }
    private val saveFile get() = File(saveDir, "$gameId.sav")
    private val stateFile get() = File(stateDir, "$gameId.ss0")
    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        folder = prefs.getString("folder", null)?.let { Uri.parse(it) }
        loadAssignments()
        render()
    }
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        clearTouches()
        render()
    }
    private fun btn(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 12f
        setOnClickListener { action() }
    }
    private fun render() {
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(19, 23, 33))
        }
        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("ROM" to { pickRom() }, "Save" to { saveAll() }, "Load" to { loadState() }, "Files" to { fileMenu() }, "⚙" to { options() }).forEach { (name, action) ->
            toolbar.addView(btn(name, action), LinearLayout.LayoutParams(0, 44.dp, 1f))
        }
        root.addView(toolbar)
        screen = GameScreen()
        if (landscape) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(dpad(), LinearLayout.LayoutParams(152.dp, 200.dp))
            row.addView(screen, LinearLayout.LayoutParams(0, -1, 1f))
            row.addView(actionPad(true), LinearLayout.LayoutParams(160.dp, 200.dp))
            root.addView(row, LinearLayout.LayoutParams(-1, 0, 1f))
        } else {
            root.addView(screen, LinearLayout.LayoutParams(-1, 0, 1f))
            val shoulders = LinearLayout(this).apply { gravity = Gravity.CENTER }
            shoulders.addView(keyButton("L"), LinearLayout.LayoutParams(0, 52.dp, 1f))
            shoulders.addView(TextView(this).apply { text = "GBA POCKET"; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, 52.dp, 1f))
            shoulders.addView(keyButton("R"), LinearLayout.LayoutParams(0, 52.dp, 1f))
            root.addView(shoulders)
            val controls = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            controls.addView(dpad(), LinearLayout.LayoutParams(0, 178.dp, 1f))
            controls.addView(actionPad(false), LinearLayout.LayoutParams(0, 178.dp, 1f))
            root.addView(controls)
        }
        setContentView(root)
    }
    private fun loadAssignments() {
        val global = defaultAssignments.mapValues { (button, value) ->
            prefs.getString("mapping_default_$button", value) ?: value
        }
        assignments = if (loaded && gameId.isNotEmpty()) global.mapValues { (button, value) ->
            prefs.getString("mapping_rom_${gameId}_$button", value) ?: value
        } else global
        updateKeyMask()
    }
    private fun updateKeyMask() {
        synchronized(touchLock) {
            var mask = 0
            for (button in activeTouches.values) {
                val assigned = assignments[button] ?: button
                val bit = libretroIds[assigned] ?: continue
                mask = mask or (1 shl bit)
            }
            keys.set(mask)
        }
    }
    private fun clearTouches() {
        synchronized(touchLock) { activeTouches.clear(); keys.set(0) }
    }
    private fun keyButton(label: String) = Button(this).apply {
        text = when (label) { "Up" -> "↑"; "Down" -> "↓"; "Left" -> "←"; "Right" -> "→"; else -> label }
        isAllCaps = false
        textSize = 15f
        setOnTouchListener { view, event ->
            synchronized(touchLock) {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                        val index = event.actionIndex
                        activeTouches[System.identityHashCode(view) to event.getPointerId(index)] = label
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                        val index = event.actionIndex
                        activeTouches.remove(System.identityHashCode(view) to event.getPointerId(index))
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        val viewId = System.identityHashCode(view)
                        activeTouches.keys.removeAll { it.first == viewId }
                    }
                }
                updateKeyMask()
            }
            true
        }
    }
    private fun controlSettings() {
        val choices = arrayOf("Edit default mapping", "Edit this ROM mapping", "Reset default mapping", "Reset this ROM mapping")
        AlertDialog.Builder(this).setTitle("Touch controls").setItems(choices) { _, index ->
            when (index) {
                0 -> editMapping(false)
                1 -> if (loaded) editMapping(true) else toast("Open a ROM first")
                2 -> { gbaButtons.forEach { prefs.edit().remove("mapping_default_$it").apply() }; loadAssignments(); toast("Default mapping restored") }
                3 -> if (loaded) { gbaButtons.forEach { prefs.edit().remove("mapping_rom_${gameId}_$it").apply() }; loadAssignments(); toast("ROM mapping restored") } else toast("Open a ROM first")
            }
        }.show()
    }
    private fun editMapping(forRom: Boolean) {
        val prefix = if (forRom) "mapping_rom_${gameId}_" else "mapping_default_"
        val values = gbaButtons.map { button ->
            val current = prefs.getString(prefix + button, if (forRom) prefs.getString("mapping_default_$button", button) else button) ?: button
            "$button → $current"
        }.toTypedArray()
        AlertDialog.Builder(this).setTitle(if (forRom) "ROM controls: $romName" else "Default controls")
            .setItems(values) { _, index ->
                val button = gbaButtons[index]
                AlertDialog.Builder(this).setTitle("$button sends:")
                    .setSingleChoiceItems(gbaButtons.toTypedArray(), -1) { dialog, selected ->
                        prefs.edit().putString(prefix + button, gbaButtons[selected]).apply()
                        loadAssignments()
                        dialog.dismiss()
                        editMapping(forRom)
                    }.setNegativeButton("Cancel", null).show()
            }.setNegativeButton("Close", null).show()
    }
    private fun dpad(): View {
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val rows = listOf(listOf(null, "Up", null), listOf("Left", null, "Right"), listOf(null, "Down", null))
        rows.forEach { items ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
            items.forEach { item ->
                row.addView(if (item == null) View(this) else keyButton(item), LinearLayout.LayoutParams(49.dp, 49.dp))
            }
            grid.addView(row)
        }
        return grid
    }
    private fun actionPad(landscape: Boolean): View {
        val pad = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val face = LinearLayout(this).apply { gravity = Gravity.CENTER }
        face.addView(keyButton("B"), LinearLayout.LayoutParams(70.dp, 68.dp))
        face.addView(keyButton("A"), LinearLayout.LayoutParams(70.dp, 68.dp))
        pad.addView(face)
        val center = LinearLayout(this).apply { gravity = Gravity.CENTER }
        center.addView(keyButton("Select"), LinearLayout.LayoutParams(75.dp, 50.dp))
        center.addView(keyButton("Start"), LinearLayout.LayoutParams(75.dp, 50.dp))
        pad.addView(center)
        if (landscape) {
            val shoulders = LinearLayout(this)
            shoulders.addView(keyButton("L"), LinearLayout.LayoutParams(0, 50.dp, 1f))
            shoulders.addView(keyButton("R"), LinearLayout.LayoutParams(0, 50.dp, 1f))
            pad.addView(shoulders)
        }
        return pad
    }
    private fun pickRom() = startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
        type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE)
    }, romPicker)
    private fun fileMenu() {
        val actions = arrayOf("Choose accessible save folder", "Export .sav to folder", "Import .sav", "Export state to folder")
        AlertDialog.Builder(this).setTitle("Save files").setItems(actions) { _, i ->
            when(i) {
                0 -> startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply { addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }, folderPicker)
                1 -> exportFile(saveFile, "Saves")
                2 -> if (loaded) startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }, importPicker) else toast("Open a ROM first")
                3 -> exportFile(stateFile, "States")
            }
        }.show()
    }
    private fun options() {
        AlertDialog.Builder(this).setTitle("GBA Pocket v1.2")
            .setItems(arrayOf("Save state (slot 0)", "Load state (slot 0)", "Save game (.sav)", "Save files folder", "Touch controls")) { _, i ->
                when(i) { 0 -> saveState(); 1 -> loadState(); 2 -> saveRam(); 3 -> fileMenu(); 4 -> controlSettings() }
            }.show()
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun pauseWorker() { running = false; worker?.join(); worker = null; clearTouches() }
    private fun resumeWorker() {
        if (!loaded || worker != null) return
        running = true
        worker = Thread {
            while (running) {
                val begin = System.nanoTime()
                val frame = NativeBridge.frame(keys.get())
                if (frame != null) screen.post { screen.setFrame(frame) }
                val remaining = 16_742_706L - (System.nanoTime() - begin)
                if (remaining > 0) Thread.sleep(remaining / 1_000_000, (remaining % 1_000_000).toInt())
            }
        }.also { it.start() }
    }
    private inline fun <T> withPaused(block: () -> T): T {
        val wasRunning = running
        pauseWorker()
        return try { block() } finally { if (wasRunning) resumeWorker() }
    }
    private fun saveRam() {
        if (!loaded) { toast("Open a ROM first"); return }
        withPaused {
            val bytes = NativeBridge.readSave()
            if (bytes != null) { saveFile.writeBytes(bytes); toast("Game saved") }
            else toast("Save RAM not available yet. Use in-game Save first")
        }
    }
    private fun saveState() {
        if (!loaded) { toast("Open a ROM first"); return }
        withPaused {
            val bytes = NativeBridge.saveState()
            if (bytes != null) { stateFile.writeBytes(bytes); toast("State saved") } else toast("State save unsupported")
        }
    }
    private fun loadState() {
        if (!loaded || !stateFile.exists()) { toast("No saved state for this ROM"); return }
        withPaused { toast(if (NativeBridge.loadState(stateFile.readBytes())) "State loaded" else "State incompatible") }
    }
    private fun saveAll() { saveRam(); saveState() }
    private fun stopGame() {
        pauseWorker()
        if (loaded) {
            NativeBridge.readSave()?.let { saveFile.writeBytes(it) }
            NativeBridge.unload()
            loaded = false
            gameId = ""
            loadAssignments()
        }
    }
    private fun exportFile(file: File, category: String) {
        if (!file.exists()) { toast("No file to export"); return }
        val tree = folder ?: run { toast("Choose a save folder first"); return }
        try {
            val root = DocumentsContract.getTreeDocumentId(tree)
            val rootUri = DocumentsContract.buildDocumentUriUsingTree(tree, root)
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, root)
            val cursor = contentResolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)
            var target: Uri? = null
            cursor?.use {
                while (it.moveToNext()) if (it.getString(1) == file.name) target = DocumentsContract.buildDocumentUriUsingTree(tree, it.getString(0))
            }
            if (target != null) { toast("File exists in folder; rename or remove it before exporting"); return }
            target = DocumentsContract.createDocument(contentResolver, rootUri, "application/octet-stream", file.name)
            target?.let { uri -> contentResolver.openOutputStream(uri)?.use { it.write(file.readBytes()) }; toast("Exported $category/${file.name}") }
        } catch (e: Exception) { toast("Export failed: ${e.message}") }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (requestCode == folderPicker) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                folder = uri; prefs.edit().putString("folder", uri.toString()).apply(); toast("Save folder selected")
            } catch (e: Exception) { toast("Folder access denied") }
            return
        }
        if (requestCode == importPicker) {
            if (!loaded) return
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return
            withPaused {
                val current = NativeBridge.readSave()
                if (current == null || bytes.size != current.size) { toast("Save size incompatible"); return@withPaused }
                AlertDialog.Builder(this).setTitle("Replace game save?")
                    .setMessage("Current save will be backed up before import. Import only a save from this same game.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Import") { _, _ ->
                        withPaused {
                            if (saveFile.exists()) saveFile.copyTo(File(saveDir, "$gameId.backup.sav"), overwrite = true)
                            if (NativeBridge.writeSave(bytes)) { saveFile.writeBytes(bytes); toast("Save imported") } else toast("Import failed")
                        }
                    }.show()
            }
            return
        }
        if (requestCode != romPicker) return
        val name = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else "" } ?: ""
        if (!name.lowercase().endsWith(".gba")) { toast("Choose a .gba ROM"); return }
        stopGame()
        try {
            val rom = File(cacheDir, "current.gba")
            contentResolver.openInputStream(uri)?.use { input -> rom.outputStream().use { input.copyTo(it) } } ?: return
            val digest = MessageDigest.getInstance("SHA-256").digest(rom.readBytes())
            gameId = digest.take(12).joinToString("") { "%02x".format(it) }
            romName = name
            loaded = NativeBridge.load(rom.absolutePath, filesDir.absolutePath)
            if (!loaded) { toast("Could not load ROM/core"); return }
            NativeBridge.frame(0) // Initialize save memory before restoring persisted SRAM.
            if (saveFile.exists()) {
                val ok = NativeBridge.writeSave(saveFile.readBytes())
                if (!ok) toast("Existing save could not be restored")
            }
            loadAssignments()
            resumeWorker()
            toast("Loaded $romName")
        } catch (e: Exception) { toast("ROM error: ${e.message}") }
    }
    override fun onPause() { if (loaded) withPaused { NativeBridge.readSave()?.let { saveFile.writeBytes(it) } }; pauseWorker(); super.onPause() }
    override fun onResume() { super.onResume(); if (loaded) resumeWorker() }
    override fun onDestroy() { stopGame(); super.onDestroy() }
    override fun onBackPressed() {
        if (!loaded) { super.onBackPressed(); return }
        AlertDialog.Builder(this).setMessage("Save and exit GBA Pocket?")
            .setPositiveButton("Save & Exit") { _, _ -> stopGame(); finish() }
            .setNegativeButton("Continue", null).show()
    }
    inner class GameScreen : View(this) {
        private val paint = Paint().apply { isFilterBitmap = false }
        private var bitmap: Bitmap? = null
        fun setFrame(pixels: IntArray) { bitmap = Bitmap.createBitmap(pixels, 240, 160, Bitmap.Config.ARGB_8888); invalidate() }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas); canvas.drawColor(Color.BLACK)
            bitmap?.let { val scale = minOf(width / 240f, height / 160f); val w = 240 * scale; val h = 160 * scale
                canvas.drawBitmap(it, null, android.graphics.RectF((width-w)/2, (height-h)/2, (width+w)/2, (height+h)/2), paint) }
        }
    }
}
object NativeBridge {
    init { System.loadLibrary("mgba_libretro"); System.loadLibrary("gba_bridge") }
    external fun load(rom: String, saves: String): Boolean
    external fun frame(keys: Int): IntArray?
    external fun unload()
    external fun readSave(): ByteArray?
    external fun writeSave(bytes: ByteArray): Boolean
    external fun saveState(): ByteArray?
    external fun loadState(bytes: ByteArray): Boolean
}
