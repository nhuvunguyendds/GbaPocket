# GBA Pocket v1.2 touch controls

- Fixed libretro joypad button IDs: A=8, B=0, L=10, R=11, Select=2, Start=3, Up=4, Down=5, Left=6, Right=7.
- Simultaneous independent touch buttons are aggregated into one bitmask. L+A, L+B, R+A, R+B and other combinations work in the same frame.
- Options (gear icon) > Touch controls: edit global defaults or the loaded ROM's overrides; reset either set.
- ROM mappings are saved by ROM SHA-256 prefix and inherit defaults unless overridden.
- Note: the GitHub Actions workflow from build #19 rewrites app/build.gradle.kts at build time and may set versionName back to 1.1; update that workflow's versionCode and versionName to 3 and 1.2 if desired.
- The build has not been executed in this environment; validate in GitHub Actions and test on a device.
