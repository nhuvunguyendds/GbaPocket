# GBA Pocket — bundled mGBA source integration

This archive contains the **actual upstream mGBA source supplied by the user**, under `third_party/mgba-master/`. The Android CMake build compiles its Libretro core and the JNI bridge together, so downloading mGBA separately is no longer required.

## Build an APK

1. Open `GbaPocket/` in Android Studio with Android SDK Platform 35, Android NDK and CMake installed.
2. Sync Gradle and select **Build > Build APK(s)**. Android Studio will build `libmgba_libretro.so` for ARM64 as part of externalNativeBuild.
3. Install the debug APK and select an **uncompressed `.gba` file**. For a ROM packaged in ZIP, extract it before selecting.

Alternatively, on a machine with the Android SDK/NDK and Gradle installed, run `gradle assembleDebug` in the project directory. This archive does not include the Gradle wrapper or a prebuilt APK.

## Limitations / validation

- Upstream source presence and build wiring were verified by inspecting files, **not by compiling**: this environment has no Android SDK/NDK.
- Audio is currently silent; SRAM save and save-state UX are not implemented or verified.
- ROM compatibility and gameplay for Harvest Moon have **not** been tested on Android.
- The existing JNI bridge expects `libmgba_libretro.so`; its video callback supports 240×160 output and RGB565/XRGB8888.
- The frontend only supports `.gba` files, not ZIP containers.
- License: mGBA upstream license is in `third_party/mgba-master/LICENSE`. Keep required notices and comply with licenses before distribution.

Upstream project: https://github.com/mgba-emu/mgba

## GitHub Actions build (Android phone only)
Upload this project as a Git repository (do not commit the Harvest Moon ROM). Run Actions > Build GBA Pocket APK > Run workflow. Download the artifact when successful. The build has not been validated in this environment.

Fixes in this revision: loads libmgba_libretro before JNI bridge, links it as a native dependency to ensure APK packaging, and adds a pinned Gradle 8.9 cloud workflow.
