#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
: "${ANDROID_NDK_HOME:?Set ANDROID_NDK_HOME to your Android NDK directory}"
cmake -S "$ROOT/third_party/mgba-master" -B "$ROOT/build/mgba-arm64" \
  -G Ninja -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-26 \
  -DCMAKE_BUILD_TYPE=Release -DBUILD_LIBRETRO=ON -DBUILD_QT=OFF \
  -DBUILD_SDL=OFF -DBUILD_SHARED=OFF -DBUILD_STATIC=OFF \
  -DSKIP_LIBRARY=ON -DDISABLE_DEPS=ON -DUSE_ZLIB=OFF
cmake --build "$ROOT/build/mgba-arm64" --target mgba_libretro -j 4
mkdir -p "$ROOT/app/src/main/jniLibs/arm64-v8a"
CORE="$(find "$ROOT/build/mgba-arm64" -name 'mgba_libretro.so' -o -name 'libmgba_libretro.so' | head -1)"
test -n "$CORE"
cp "$CORE" "$ROOT/app/src/main/jniLibs/arm64-v8a/libmgba_libretro.so"
echo "Core ready: $ROOT/app/src/main/jniLibs/arm64-v8a/libmgba_libretro.so"
